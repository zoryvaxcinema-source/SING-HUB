/**
 * Singhub Karaoke Engine & Player Controller
 * 100% Offline Capable - Native Hardware Audio & Syllable Synchronization
 * Clean Broadcast TV Stage with Idle Select A Song Screen
 */

(function () {
  'use strict';

  const AUTH_HEADERS = { 'X-Singhub-App': 'Singhub-Official-App-2026-Signed' };

  // --- 1. Audio Context & Arcade Sound Effects ---
  let audioCtx = null;
  function getAudioCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playKeyBeep(freq = 1100) {
    try {
      const ctx = getAudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch (e) {}
  }

  function playCountdownPip(isFinal = false) {
    try {
      const ctx = getAudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = isFinal ? 'square' : 'triangle';
      const freq = isFinal ? 1760 : 880;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(isFinal ? 0.25 : 0.16, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (isFinal ? 0.3 : 0.09));
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + (isFinal ? 0.3 : 0.09));
    } catch (e) {}
  }

  function playFanfareChords() {
    if (window.SinghubNative && window.SinghubNative.playScoreFanfareNative) {
      window.SinghubNative.playScoreFanfareNative();
      return;
    }
    try {
      const audio = new Audio('/audio/videoke_score_fanfare.mp3');
      audio.volume = 1.0;
      audio.play().catch(e => {});
    } catch (e) {}
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // --- 2. State & Variables ---
  let isPlaying = false;
  let currentSong = null;
  let songLines = [];
  let currentLineIdx = -1;
  let playbackStartTime = 0;
  let pausedAtTime = 0;
  let keyShift = 0; // -6 to +6
  let tempoShift = 0; // -10 to +10
  let songQueue = [];
  let lastCountdownNumber = 0;
  let dialBuffer = '';
  let dialAutoPlayTimer = null;
  let playingCycleIndex = 0;

  const mp3Player = document.getElementById('mp3-player');
  const topLine = document.getElementById('lyric-top-line');
  const bottomLine = document.getElementById('lyric-bottom-line');
  const introCard = document.getElementById('stage-intro-card');
  const interludeBanner = document.getElementById('stage-interlude-banner');
  const countdownElem = document.getElementById('countdown-elem');
  const stageIdleSelect = document.getElementById('stage-idle-select');
  const idleSelectDigits = document.getElementById('idle-select-digits');
  const idleSelectSub = document.getElementById('idle-select-sub');
  const tvDialHud = document.getElementById('tv-dial-hud');
  const tvDialDigits = document.getElementById('tv-dial-digits');
  const tvDialTitle = document.getElementById('tv-dial-title');
  const topPlayingLine = document.getElementById('top-playing-line');

  // --- 3. Synchronized Audio Timing & Score Modal Control ---
  let lastReportedAudioTime = 0;
  let lastAudioQueryPerf = 0;
  let cachedNativeAudioTime = 0;
  let isEndingSong = false;
  let scoreModalDismissTimer = null;
  let scoreDelayTimer = null;

  function resetAudioClock() {
    lastReportedAudioTime = 0;
    cachedNativeAudioTime = 0;
    lastAudioQueryPerf = 0;
    pausedAtTime = 0;
    playbackStartTime = performance.now();
  }

  function dismissScoreModal() {
    if (scoreDelayTimer) { clearTimeout(scoreDelayTimer); scoreDelayTimer = null; }
    if (scoreModalDismissTimer) { clearTimeout(scoreModalDismissTimer); scoreModalDismissTimer = null; }
    isEndingSong = false;
    const sm = document.getElementById('modal-score');
    if (sm) sm.style.display = 'none';
  }

  function getAudioTime() {
    if (!isPlaying) return pausedAtTime;

    const now = performance.now();
    // Query native every 60ms to avoid synchronous JNI overhead, and interpolate smoothly with performance.now()
    if (window.SinghubNative && window.SinghubNative.getNativeAudioTime) {
      if (now - lastAudioQueryPerf > 60) {
        lastAudioQueryPerf = now;
        try {
          const nt = Number(window.SinghubNative.getNativeAudioTime());
          if (nt > 0) cachedNativeAudioTime = nt;
        } catch (e) {}
      }
      if (cachedNativeAudioTime > 0) {
        const interpolated = cachedNativeAudioTime + ((now - lastAudioQueryPerf) / 1000);
        lastReportedAudioTime = Math.max(lastReportedAudioTime, interpolated);
        return lastReportedAudioTime;
      }
    }

    if (currentSong && currentSong.hasAudio && mp3Player && !mp3Player.paused) {
      lastReportedAudioTime = Math.max(lastReportedAudioTime, mp3Player.currentTime);
      return lastReportedAudioTime;
    }

    const webMidi = document.getElementById('web-midi-player');
    if (webMidi && webMidi.player && typeof webMidi.player.isPlaying === 'function' && webMidi.player.isPlaying()) {
      const wt = Number(webMidi.currentTime) || 0;
      if (wt > 0) {
        lastReportedAudioTime = Math.max(lastReportedAudioTime, wt);
        return lastReportedAudioTime;
      }
    }

    const fallbackTime = Math.max(0, (now - playbackStartTime) / 1000);
    lastReportedAudioTime = Math.max(lastReportedAudioTime, fallbackTime);
    return lastReportedAudioTime;
  }

  function asNativeBool(v) {
    // Android WebView sometimes returns the strings "true"/"false" — "false" is truthy in JS!
    return v === true || v === 1 || v === 'true' || v === '1';
  }

  function startWebMidiFallback(midiUrl) {
    try {
      const wm = document.getElementById('web-midi-player');
      if (!wm || !midiUrl) return false;
      // Ensure offline soundfont is set (defaults to SAM5504B/web_gm or active custom .sf2)
      try {
        if (!wm.getAttribute('sound-font')) {
          wm.setAttribute('sound-font', '/api/soundfont/active');
        }
      } catch (e) {}
      wm.src = midiUrl;
      if (typeof wm.start === 'function') {
        wm.start();
        return true;
      }
    } catch (e) {
      console.warn('Web MIDI fallback error:', e);
    }
    return false;
  }

  function startBrowserAudioFallback(data) {
    if (data.hasAudio && data.audioUrl && mp3Player) {
      try {
        mp3Player.src = data.audioUrl;
        mp3Player.currentTime = 0;
        mp3Player.play().catch(e => {});
        return true;
      } catch (e) {}
    }
    if (data.midiUrl) {
      return startWebMidiFallback(data.midiUrl);
    }
    return false;
  }

  let activeSyllables = [];

  function escapeHtml(str) {
    return (str || '').replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  function buildLineTimings(box, lineObj) {
    if (!lineObj) return null;
    const syllables = lineObj.syllables || [];
    const lineStart = lineObj.start !== undefined ? lineObj.start : (syllables[0] ? syllables[0].time : 0);
    const lastSyl = syllables[syllables.length - 1];
    const lineEnd = lineObj.end !== undefined ? lineObj.end : (lastSyl ? (lastSyl.time + 1.2) : (lineStart + 4.0));

    if (!syllables || syllables.length === 0) {
      return {
        start: lineStart,
        end: lineEnd,
        isLinear: true
      };
    }

    const points = [];
    const markers = box ? box.querySelectorAll('.syl-marker') : null;
    const boxRect = box ? box.getBoundingClientRect() : null;
    const boxWidth = boxRect ? boxRect.width : 0;

    let fullText = lineObj.text || syllables.map(s => s.text).join('');
    const fullLen = Math.max(1, fullText.length);
    let curCharIdx = 0;

    for (let i = 0; i < syllables.length; i++) {
      const s = syllables[i];
      let frac = 0;

      // Primary: exact screen pixel position of syllable start
      if (markers && markers[i] && boxWidth > 0 && boxRect) {
        const mRect = markers[i].getBoundingClientRect();
        frac = Math.max(0, Math.min(1, (mRect.left - boxRect.left) / boxWidth));
      } else {
        // Fallback: character index fraction
        let idx = fullText.indexOf(s.text, curCharIdx);
        if (idx === -1) idx = curCharIdx;
        frac = idx / fullLen;
        curCharIdx = idx + (s.text ? s.text.length : 1);
      }

      points.push({ time: s.time, frac: frac });
    }

    const finalEndTime = Math.max(lastSyl.time + 0.6, lineEnd);
    points.push({ time: finalEndTime, frac: 1.0 });

    return {
      start: lineStart,
      end: finalEndTime,
      points: points,
      isLinear: false
    };
  }

  function getSmoothLineProgress(timings, t) {
    if (!timings) return 0;
    if (t <= timings.start) return 0;
    if (t >= timings.end) return 100;

    if (timings.isLinear) {
      const dur = timings.end - timings.start;
      if (dur <= 0) return 100;
      return Math.max(0, Math.min(100, ((t - timings.start) / dur) * 100));
    }

    const pts = timings.points;
    if (!pts || pts.length === 0) return 0;

    if (t <= pts[0].time) return pts[0].frac * 100;

    for (let i = 0; i < pts.length - 1; i++) {
      const p1 = pts[i];
      const p2 = pts[i + 1];
      if (t >= p1.time && t <= p2.time) {
        const span = p2.time - p1.time;
        const ratio = span > 0 ? (t - p1.time) / span : 0;
        const frac = p1.frac + ratio * (p2.frac - p1.frac);
        return Math.max(0, Math.min(100, frac * 100));
      }
    }

    return 100;
  }

  function renderLine(container, lineObj, isCompleted = false) {
    if (!container) return;
    container.innerHTML = '';
    container._timings = null;
    container._lineText = null;
    container._lineObj = lineObj;
    container._lineIndex = (songLines && lineObj) ? songLines.indexOf(lineObj) : -1;
    container._lastProg = isCompleted ? '100.0%' : '0.0%';

    if (!lineObj) return;

    const syllables = (lineObj.syllables && lineObj.syllables.length > 0) ? lineObj.syllables : null;
    let fullText = lineObj.text || '';
    if (!fullText && syllables) fullText = syllables.map(s => s.text).join('');

    let spansHtml = '';
    if (syllables && syllables.length > 0) {
      for (let i = 0; i < syllables.length; i++) {
        const s = syllables[i];
        const esc = escapeHtml(s.text);
        spansHtml += `<span class="syl-marker" data-syl-idx="${i}">${esc}</span>`;
      }
    } else {
      spansHtml = escapeHtml(fullText);
    }

    const initProg = isCompleted ? '100%' : '0%';
    container.innerHTML = `<div class="lyric-line-text" style="--line-prog:${initProg};">${spansHtml}</div>`;

    const lineText = container.querySelector('.lyric-line-text');
    container._lineText = lineText;
    container._timings = buildLineTimings(lineText, lineObj);

    if (lineText && (!container._timings || container._timings.isLinear)) {
      requestAnimationFrame(() => {
        if (container._lineText && container._lineObj) {
          container._timings = buildLineTimings(container._lineText, container._lineObj);
        }
      });
    }
  }

  // --- 4. Idle State Display ---
  function showIdleSelectState() {
    isPlaying = false;
    currentSong = null;
    songLines = [];
    currentLineIdx = -1;
    keyShift = 0;
    tempoShift = 0;
    updateDeckPitchTempoBadges();

    dismissScoreModal();
    resetAudioClock();

    if (stageIdleSelect) stageIdleSelect.style.display = 'flex';
    if (idleSelectDigits) idleSelectDigits.textContent = '000000';
    if (idleSelectSub) idleSelectSub.textContent = 'Enter Song Number on Remote or Keypad';

    if (topLine) { topLine.innerHTML = ''; topLine._lineText = null; topLine._timings = null; topLine.style.display = 'none'; }
    if (bottomLine) { bottomLine.innerHTML = ''; bottomLine._lineText = null; bottomLine._timings = null; bottomLine.style.display = 'none'; }
    if (introCard) introCard.style.display = 'none';
    if (interludeBanner) interludeBanner.style.display = 'none';
    if (countdownElem) countdownElem.style.display = 'none';
    if (tvDialHud) tvDialHud.style.display = 'none';

    updatePlayingHeader();
    broadcastState();
  }

  // --- 5. Cycling Header Line: PLAYING ---
  function updatePlayingHeader() {
    if (!topPlayingLine) return;

    if (!isPlaying || !currentSong) {
      topPlayingLine.textContent = 'PLAYING: None';
      return;
    }

    const curNumPadded = String(currentSong.num).padStart(5, '0');
    const queueNums = songQueue.map(s => String(s.num).padStart(5, '0'));
    const allNums = [curNumPadded, ...queueNums].join(' , ');

    if (playingCycleIndex === 0) {
      // e.g. PLAYING: 00007 , 33055 , 00054
      topPlayingLine.textContent = `PLAYING: ${allNums}`;
    } else if (playingCycleIndex === 1) {
      // e.g. PLAYING: 00007 - 'DI KA SAYANG
      topPlayingLine.textContent = `PLAYING: ${curNumPadded} - ${currentSong.title.toUpperCase()}`;
    } else {
      // e.g. PLAYING: Next 33055 - PERFECT
      if (songQueue.length > 0) {
        const next = songQueue[0];
        topPlayingLine.textContent = `PLAYING: Next ${String(next.num).padStart(5, '0')} - ${next.title.toUpperCase()}`;
      } else {
        topPlayingLine.textContent = `PLAYING: ${curNumPadded} - ${currentSong.title.toUpperCase()}`;
      }
    }
  }

  // Cycle the playing line message every 3.5 seconds
  setInterval(() => {
    playingCycleIndex = (playingCycleIndex + 1) % 3;
    updatePlayingHeader();
  }, 3500);

  // --- 6. Animation & Lyrics Loop ---
  let lastBroadcastTime = 0;

  function syncKaraokeLoop() {
    if (isPlaying) {
      const t = getAudioTime();

      // Always hide intro card while playing
      if (introCard && introCard.style.display !== 'none') {
        introCard.style.display = 'none';
      }

      // Check if song finished (requires active playing, duration > 0, elapsed >= duration - 0.2, and at least 2.5s played)
      if (currentSong && currentSong.duration > 0 && t >= (currentSong.duration - 0.2) && t > 2.5) {
        onSongCompleted();
        requestAnimationFrame(syncKaraokeLoop);
        return;
      }

      if (songLines.length > 0) {
        // Initial lines render if not yet set
        if (currentLineIdx === -1) {
          currentLineIdx = 0;
          renderLine(topLine, songLines[0], false);
          renderLine(bottomLine, songLines[1] || null, false);
          if (topLine) topLine.classList.add('active-singing');
          if (bottomLine) bottomLine.classList.remove('active-singing');
          broadcastState();
        }

        // Always show lyric rows once active
        if (topLine) topLine.style.display = 'flex';
        if (bottomLine) bottomLine.style.display = 'flex';

        // 1. Intro Music Phase
        if (t < songLines[0].start) {
          const timeUntilStart = songLines[0].start - t;

          if (timeUntilStart <= 5.0 && timeUntilStart > 0) {
            updateCountdown(timeUntilStart);
          } else {
            if (countdownElem) countdownElem.style.display = 'none';
            lastCountdownNumber = 0;
          }
        } else {
          // Preserve the last pip between frames during interlude countdowns.
          // The branches below reset it when no countdown is active.
          if (introCard) introCard.style.display = 'none';

          // 2. Active Singing Phase: Locate active line with O(1) step
          let activeIdx = Math.max(0, currentLineIdx);
          if (t < songLines[activeIdx].start) activeIdx = 0;
          while (activeIdx + 1 < songLines.length && t >= songLines[activeIdx + 1].start) {
            activeIdx++;
          }

          const curLine = songLines[activeIdx];
          const nextLine = songLines[activeIdx + 1];

          // Always keep lyric rows visible
          if (topLine) topLine.style.display = 'flex';
          if (bottomLine) bottomLine.style.display = 'flex';

          // Interlude Banner Check
          if (curLine && t > curLine.end && nextLine) {
            const gap = nextLine.start - curLine.end;
            const timeUntilNext = nextLine.start - t;

            if (gap >= 6.0) {
              if (timeUntilNext > 5.0) {
                if (interludeBanner) interludeBanner.style.display = 'flex';
                if (countdownElem) countdownElem.style.display = 'none';
                lastCountdownNumber = 0;
              } else if (timeUntilNext <= 5.0 && timeUntilNext > 0) {
                if (interludeBanner) interludeBanner.style.display = 'none';
                updateCountdown(timeUntilNext);
              }
            } else {
              if (interludeBanner) interludeBanner.style.display = 'none';
              if (countdownElem) countdownElem.style.display = 'none';
              lastCountdownNumber = 0;
            }
          } else {
            if (interludeBanner) interludeBanner.style.display = 'none';
            if (countdownElem) countdownElem.style.display = 'none';
            lastCountdownNumber = 0;
          }

          // 3. Ping-Pong 2-Line Alternation with Active Line Elevation
          if (activeIdx !== currentLineIdx) {
            currentLineIdx = activeIdx;
            if (currentLineIdx % 2 === 0) {
              renderLine(topLine, songLines[currentLineIdx], false);
              renderLine(bottomLine, songLines[currentLineIdx + 1] || null, false);
              if (topLine) topLine.classList.add('active-singing');
              if (bottomLine) bottomLine.classList.remove('active-singing');
            } else {
              renderLine(bottomLine, songLines[currentLineIdx], false);
              renderLine(topLine, songLines[currentLineIdx + 1] || null, false);
              if (bottomLine) bottomLine.classList.add('active-singing');
              if (topLine) topLine.classList.remove('active-singing');
            }
            broadcastState();
          }
        } // end songLines > 0 else block
      } // end songLines.length > 0

      // 4. Continuous Smooth Line Progress Wipe (Silky & Zero Redundant Repaints)
      if (topLine && topLine._lineText) {
        let prog = 0;
        if (currentLineIdx !== -1) {
          if (currentLineIdx % 2 === 0) {
            prog = getSmoothLineProgress(topLine._timings, t);
          } else {
            const lineNum = (topLine._lineIndex !== undefined && topLine._lineIndex >= 0) ? topLine._lineIndex : (topLine._lineObj ? songLines.indexOf(topLine._lineObj) : -1);
            prog = (lineNum !== -1 && lineNum < currentLineIdx) ? 100 : 0;
          }
        }
        const pStr = prog.toFixed(1) + '%';
        if (topLine._lastProg !== pStr) {
          topLine._lastProg = pStr;
          topLine._lineText.style.setProperty('--line-prog', pStr);
        }
      }

      if (bottomLine && bottomLine._lineText) {
        let prog = 0;
        if (currentLineIdx !== -1) {
          if (currentLineIdx % 2 !== 0) {
            prog = getSmoothLineProgress(bottomLine._timings, t);
          } else {
            const lineNum = (bottomLine._lineIndex !== undefined && bottomLine._lineIndex >= 0) ? bottomLine._lineIndex : (bottomLine._lineObj ? songLines.indexOf(bottomLine._lineObj) : -1);
            prog = (lineNum !== -1 && lineNum < currentLineIdx) ? 100 : 0;
          }
        }
        const pStr = prog.toFixed(1) + '%';
        if (bottomLine._lastProg !== pStr) {
          bottomLine._lastProg = pStr;
          bottomLine._lineText.style.setProperty('--line-prog', pStr);
        }
      }

      // 5. Periodic state broadcast for real-time remote lyric & progress sync (every 400ms)
      const now = performance.now();
      if (now - lastBroadcastTime > 400) {
        lastBroadcastTime = now;
        broadcastState();
      }
    }

    requestAnimationFrame(syncKaraokeLoop);
  }

  function updateCountdown(secondsLeft) {
    if (secondsLeft > 5.0 || secondsLeft <= 0) {
      if (countdownElem) countdownElem.style.display = 'none';
      lastCountdownNumber = 0;
      return;
    }

    const num = Math.max(1, Math.min(5, Math.ceil(secondsLeft)));
    if (countdownElem) {
      countdownElem.textContent = num;
      countdownElem.style.display = 'block';
      countdownElem.style.color = num === 1 ? '#00f59b' : '#ffb703';
    }

    if (num !== lastCountdownNumber) {
      lastCountdownNumber = num;
      playCountdownPip(num === 1);
    }
  }

  // --- 7. Song Loading & Hardware Audio Playback ---
  let intro5sTimer = null;
  let audioWatchdogTimer = null;

  async function loadSong(songNum) {
    try {
      getAudioCtx();
      dismissScoreModal();
      resetAudioClock();

      if (intro5sTimer) { clearTimeout(intro5sTimer); intro5sTimer = null; }
      if (audioWatchdogTimer) { clearTimeout(audioWatchdogTimer); audioWatchdogTimer = null; }
      const sm = document.getElementById('modal-score');
      if (sm) sm.style.display = 'none';

      if (window.SinghubNative && window.SinghubNative.stopNative) {
        try { window.SinghubNative.stopNative(); } catch (e) {}
      }
      if (mp3Player) {
        mp3Player.pause();
        mp3Player.volume = 1.0;
      }
      const wm = document.getElementById('web-midi-player');
      if (wm && wm.player) {
        try { wm.stop(); } catch (e) {}
      }
      isPlaying = false;

      const res = await fetch(`/api/song/${songNum}`, { headers: AUTH_HEADERS });
      if (!res.ok) {
        showToast(`Song #${songNum} not found`);
        return;
      }

      const data = await res.json();
      currentSong = data;
      songLines = data.lines || [];
      currentLineIdx = -1;
      lastCountdownNumber = 0;
      keyShift = 0;
      tempoShift = 0;
      updateDeckPitchTempoBadges();

      // Hide Idle Screen & TV dial HUD
      if (stageIdleSelect) stageIdleSelect.style.display = 'none';
      if (tvDialHud) tvDialHud.style.display = 'none';

      // Update Intro Card (Title -> Code -> Singer)
      const introT = document.getElementById('intro-title');
      const introC = document.getElementById('intro-code');
      const introA = document.getElementById('intro-artist');
      if (introT) introT.textContent = data.title;
      if (introC) introC.textContent = `#${String(data.num).padStart(5, '0')}`;
      if (introA) introA.textContent = data.artist;

      // Show Song Intro Card for 5s; hide lyrics & countdown
      if (introCard) introCard.style.display = 'flex';
      if (topLine) { topLine.style.display = 'none'; topLine.innerHTML = ''; }
      if (bottomLine) { bottomLine.style.display = 'none'; bottomLine.innerHTML = ''; }
      if (countdownElem) countdownElem.style.display = 'none';

      // Update Top Status Line
      playingCycleIndex = 0;
      updatePlayingHeader();

      // Switch BGV Video
      switchNextBgv();

      broadcastState();

      if (!songLines.length) {
        console.warn('Song #' + songNum + ' returned 0 lyric lines — MIDI extract may have failed');
      }

      // 5-Second Intro Presentation: When 5s ends, start audio, show lyrics, and start countdown
      intro5sTimer = setTimeout(() => {
        intro5sTimer = null;
        // ALWAYS hide the intro card when the 5s completes - regardless of lyrics
        if (introCard) introCard.style.display = 'none';

        resetAudioClock();
        currentLineIdx = 0;

        renderLine(topLine, songLines[0] || null, false);
        renderLine(bottomLine, songLines[1] || null, false);
        if (topLine) topLine.classList.add('active-singing');
        if (bottomLine) bottomLine.classList.remove('active-singing');

        // Show lyric rows ready for active singing
        if (topLine) topLine.style.display = 'flex';
        if (bottomLine) bottomLine.style.display = 'flex';

        // Play Native Hardware Audio (Android MediaPlayer - 100% Offline General MIDI / MP3)
        let nativeStarted = false;
        try {
          if (window.SinghubNative && window.SinghubNative.playSongNative) {
            nativeStarted = asNativeBool(window.SinghubNative.playSongNative(data.num, keyShift, tempoShift));
          }
        } catch (e) {
          console.warn('Native playSong error:', e);
          nativeStarted = false;
        }

        // Native Hardware Audio is prioritized (100% offline, 0 memory overhead, zero latency)
        // Only use browser audio fallback if native hardware audio did not start
        if (!nativeStarted) {
          startBrowserAudioFallback(data);
        } else if (!data.hasAudio && data.midiUrl) {
          // Native claimed success but many TVs are silent for MIDI — watchdog falls back to web synth
          audioWatchdogTimer = setTimeout(() => {
            audioWatchdogTimer = null;
            let nativePos = 0;
            try {
              if (window.SinghubNative && window.SinghubNative.getNativeAudioTime) {
                nativePos = Number(window.SinghubNative.getNativeAudioTime()) || 0;
              }
            } catch (e) {}
            let nativePlaying = false;
            try {
              if (window.SinghubNative && window.SinghubNative.isNativePlaying) {
                nativePlaying = asNativeBool(window.SinghubNative.isNativePlaying());
              }
            } catch (e) {}
            if (isPlaying && currentSong && currentSong.num === data.num && (nativePos < 0.2 || !nativePlaying)) {
              console.warn('Native MIDI silent/stuck — switching to web soundfont synth');
              try {
                if (window.SinghubNative && window.SinghubNative.stopNative) {
                  window.SinghubNative.stopNative();
                }
              } catch (e) {}
              startWebMidiFallback(data.midiUrl);
              resetAudioClock();
            }
          }, 1800);
        }

        isPlaying = true;
        resetAudioClock();

        broadcastState();
      }, 5000);

    } catch (err) {
      console.error('Error loading song:', err);
    }
  }

  function togglePlayPause() {
    getAudioCtx();
    const wm = document.getElementById('web-midi-player');
    if (isPlaying) {
      isPlaying = false;
      pausedAtTime = getAudioTime();
      if (window.SinghubNative && window.SinghubNative.pauseNative) {
        window.SinghubNative.pauseNative();
      }
      if (mp3Player && !mp3Player.paused) mp3Player.pause();
      if (wm && wm.player) {
        try { wm.player.pause(); } catch (e) {}
      }
    } else {
      if (!currentSong) {
        if (songQueue.length > 0) nextSong();
        return;
      }
      isPlaying = true;
      playbackStartTime = performance.now() - (pausedAtTime * 1000);
      if (window.SinghubNative && window.SinghubNative.resumeNative) {
        window.SinghubNative.resumeNative();
      }
      if (mp3Player && currentSong && currentSong.hasAudio) {
        mp3Player.currentTime = pausedAtTime;
        mp3Player.play().catch(e => {});
      }
      if (wm && wm.player) {
        try { wm.player.resume(); } catch (e) {}
      }
    }
    updatePlayingHeader();
    broadcastState();
  }

  function replaySong() {
    dismissScoreModal();
    resetAudioClock();
    if (intro5sTimer) { clearTimeout(intro5sTimer); intro5sTimer = null; }
    if (currentSong) {
      loadSong(currentSong.num);
    }
  }

  function nextSong() {
    dismissScoreModal();
    resetAudioClock();
    if (intro5sTimer) { clearTimeout(intro5sTimer); intro5sTimer = null; }
    if (audioWatchdogTimer) { clearTimeout(audioWatchdogTimer); audioWatchdogTimer = null; }

    if (window.SinghubNative && window.SinghubNative.stopNative) {
      try { window.SinghubNative.stopNative(); } catch (e) {}
    }
    if (mp3Player) {
      mp3Player.pause();
      mp3Player.currentTime = 0;
      mp3Player.volume = 1.0;
    }
    const wm = document.getElementById('web-midi-player');
    if (wm && wm.player) {
      try { wm.stop(); } catch (e) {}
    }

    if (songQueue.length > 0) {
      const next = songQueue.shift();
      // Remove from server queue
      fetch('/api/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove_queue', index: 0 })
      }).catch(e => {});
      updatePlayingHeader();
      loadSong(next.num);
    } else {
      showIdleSelectState();
    }
  }

  function stopSong() {
    dismissScoreModal();
    resetAudioClock();
    if (intro5sTimer) { clearTimeout(intro5sTimer); intro5sTimer = null; }
    if (audioWatchdogTimer) { clearTimeout(audioWatchdogTimer); audioWatchdogTimer = null; }

    if (window.SinghubNative && window.SinghubNative.stopNative) {
      try { window.SinghubNative.stopNative(); } catch (e) {}
    }
    if (mp3Player) {
      mp3Player.pause();
      mp3Player.currentTime = 0;
      mp3Player.volume = 1.0;
    }
    const wm = document.getElementById('web-midi-player');
    if (wm && wm.player) {
      try { wm.stop(); } catch (e) {}
    }

    showIdleSelectState();
  }

  function playRandomSong() {
    fetch('/api/search?q=&limit=1&offset=' + Math.floor(Math.random() * 500), { headers: AUTH_HEADERS })
      .then(res => res.json())
      .then(data => {
        if (data.results && data.results.length > 0) {
          loadSong(data.results[0].num);
        } else {
          showIdleSelectState();
        }
      })
      .catch(() => showIdleSelectState());
  }

  function handlePostSongCompletion() {
    dismissScoreModal();
    if (window._pendingPatchReload) {
      window._pendingPatchReload = false;
      window.location.reload();
      return;
    }
    if (playMode === 'REPEAT') {
      if (currentSong) loadSong(currentSong.num);
      else showIdleSelectState();
    } else if (playMode === 'SINGLE') {
      showIdleSelectState();
    } else if (playMode === 'RANDOM') {
      if (songQueue.length > 0) nextSong();
      else playRandomSong();
    } else { // CONTINUOUS
      if (songQueue.length > 0) nextSong();
      else showIdleSelectState();
    }
  }

  function onSongCompleted() {
    if (isEndingSong) return;
    isEndingSong = true;
    isPlaying = false;

    if (intro5sTimer) { clearTimeout(intro5sTimer); intro5sTimer = null; }
    if (scoreDelayTimer) { clearTimeout(scoreDelayTimer); scoreDelayTimer = null; }
    if (scoreModalDismissTimer) { clearTimeout(scoreModalDismissTimer); scoreModalDismissTimer = null; }

    resetAudioClock();

    // 1. Immediately hide lyrics and banners (User: "hide the lyric if showing the scores")
    if (topLine) { topLine.style.display = 'none'; topLine.innerHTML = ''; topLine._lineText = null; topLine._timings = null; }
    if (bottomLine) { bottomLine.style.display = 'none'; bottomLine.innerHTML = ''; bottomLine._lineText = null; bottomLine._timings = null; }
    if (introCard) introCard.style.display = 'none';
    if (interludeBanner) interludeBanner.style.display = 'none';
    if (countdownElem) countdownElem.style.display = 'none';

    // 2. Slowly fade the song audio
    const fadeDurationMs = 2500;
    if (window.SinghubNative && window.SinghubNative.fadeOutSongNative) {
      try { window.SinghubNative.fadeOutSongNative(fadeDurationMs); } catch (e) {}
    }
    if (mp3Player && !mp3Player.paused) {
      const origVol = mp3Player.volume;
      const fadeStepMs = 100;
      const steps = fadeDurationMs / fadeStepMs;
      let stepCount = 0;
      const fadeInterval = setInterval(() => {
        stepCount++;
        const nextVol = Math.max(0, origVol * (1 - stepCount / steps));
        mp3Player.volume = nextVol;
        if (stepCount >= steps) {
          clearInterval(fadeInterval);
          mp3Player.pause();
          mp3Player.volume = 1.0;
        }
      }, fadeStepMs);
    }

    // 3. If scoreMode is OFF, skip score screen and proceed immediately
    if (currentSettings.scoreMode === 'OFF') {
      setTimeout(() => {
        isEndingSong = false;
        handlePostSongCompletion();
      }, 1200);
      return;
    }

    // Sound effect ONLY starts when the scoring appears and counts 1 to score
    scoreDelayTimer = setTimeout(() => {
      scoreDelayTimer = null;
      isEndingSong = false;
      showScoreModal();
    }, fadeDurationMs + 1000);
  }

  function showScoreModal() {
    if (scoreModalDismissTimer) { clearTimeout(scoreModalDismissTimer); scoreModalDismissTimer = null; }
    if (scoreDelayTimer) { clearTimeout(scoreDelayTimer); scoreDelayTimer = null; }

    // Ensure lyrics are strictly hidden
    if (topLine) { topLine.style.display = 'none'; topLine.innerHTML = ''; }
    if (bottomLine) { bottomLine.style.display = 'none'; bottomLine.innerHTML = ''; }
    if (introCard) introCard.style.display = 'none';
    if (interludeBanner) interludeBanner.style.display = 'none';
    if (countdownElem) countdownElem.style.display = 'none';

    // Calculate dynamic score based on SCORING settings (scoreDifficulty & scoreMode)
    const diff = (currentSettings.scoreDifficulty || 'MEDIUM').toUpperCase();
    const mode = (currentSettings.scoreMode || 'RANDOM').toUpperCase();
    let targetScore;
    if (diff === 'EASY') {
      // EASY: 88 to 100
      targetScore = Math.floor(Math.random() * 13) + 88;
    } else if (diff === 'HARD') {
      // HARD: 60 to 95 (or 52 to 90 if SKILL mode)
      const minS = (mode === 'SKILL') ? 52 : 62;
      const maxS = (mode === 'SKILL') ? 92 : 95;
      targetScore = Math.floor(Math.random() * (maxS - minS + 1)) + minS;
    } else {
      // MEDIUM (default): 75 to 98
      targetScore = Math.floor(Math.random() * 24) + 75;
    }

    // Dynamic celebration cheer based on final score
    let cheerText = '🌟 SUPER SINGER! 🌟';
    if (targetScore >= 98) {
      cheerText = '🏆 LEGENDARY SINGER! 🏆';
    } else if (targetScore >= 93) {
      cheerText = '🌟 SUPER SINGER! 🌟';
    } else if (targetScore >= 85) {
      cheerText = '🎉 GREAT PERFORMANCE! 🎉';
    } else if (targetScore >= 75) {
      cheerText = '👏 GOOD EFFORT! 👏';
    } else {
      cheerText = '🎤 KEEP PRACTICING! 🎤';
    }

    const scoreVal = document.getElementById('score-val');
    const scoreSub = document.getElementById('score-subtitle');
    const scoreModal = document.getElementById('modal-score');

    if (scoreVal) scoreVal.textContent = '1';
    if (scoreSub) {
      scoreSub.style.opacity = '0';
      scoreSub.textContent = cheerText;
    }

    if (scoreModal) scoreModal.style.display = 'flex';
    if (currentSettings.fanfare !== 'OFF') {
      playFanfareChords();
    }

    // Realistic arcade videoke score roll 1 to score
    const rollDuration = 3200;
    const startRollTime = performance.now();

    function stepRoll(now) {
      const elapsed = now - startRollTime;
      const progress = Math.min(1, elapsed / rollDuration);
      const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = Math.max(1, Math.min(targetScore, Math.round(1 + (targetScore - 1) * eased)));
      if (scoreVal) scoreVal.textContent = current;

      if (progress < 1) {
        requestAnimationFrame(stepRoll);
      } else {
        if (scoreVal) scoreVal.textContent = targetScore;
        if (scoreSub) {
          scoreSub.textContent = cheerText;
          scoreSub.style.opacity = '1';
          scoreSub.style.transition = 'opacity 0.6s ease, transform 0.6s cubic-bezier(0.18, 0.89, 0.32, 1.28)';
          scoreSub.style.transform = 'scale(1.15)';
          setTimeout(() => { if (scoreSub) scoreSub.style.transform = 'scale(1)'; }, 350);
        }
      }
    }
    requestAnimationFrame(stepRoll);

    // Auto dismiss after 9s and advance according to playMode
    scoreModalDismissTimer = setTimeout(() => {
      scoreModalDismissTimer = null;
      dismissScoreModal();
      handlePostSongCompletion();
    }, 9000);
  }

  // --- 8. Platinum Voice & TV Remote Quick Dial HUD ---
  const numberAudioCache = [];
  try {
    for (let i = 0; i <= 9; i++) {
      const a = new Audio(`/audio/numbers/${i}.mp3`);
      a.preload = 'auto';
      numberAudioCache.push(a);
    }
  } catch (e) {}

  function playNumberVoice(d) {
    try {
      if (d === undefined || d === null) return;
      const num = parseInt(d, 10);
      if (isNaN(num) || num < 0 || num > 9) return;
      if (window.SinghubNative && window.SinghubNative.playNumberVoiceNative) {
        window.SinghubNative.playNumberVoiceNative(num);
        return;
      }
      const audio = numberAudioCache[num] || new Audio(`/audio/numbers/${num}.mp3`);
      audio.currentTime = 0;
      audio.volume = 1.0;
      audio.play().catch(e => {
        try {
          const a2 = new Audio(`/audio/numbers/${num}.mp3?t=${Date.now()}`);
          a2.volume = 1.0;
          a2.play().catch(() => {});
        } catch (_) {}
      });
    } catch (e) {}
  }

  function updateTvDialFromBuffer(buf) {
    dialBuffer = buf || '';
    const padded = dialBuffer ? dialBuffer.padStart(6, '0') : '000000';

    const deckDigits = document.getElementById('tv-deck-digits');
    const deckTitle = document.getElementById('tv-deck-title');
    if (deckDigits) deckDigits.textContent = padded;

    if (!isPlaying && stageIdleSelect && stageIdleSelect.style.display !== 'none') {
      if (idleSelectDigits) idleSelectDigits.textContent = padded;
      if (dialBuffer) {
        const num = parseInt(dialBuffer, 10);
        // Lightweight metadata lookup (no MIDI decrypt) for instant title preview
        fetch(`/api/songmeta/${num}`)
          .then(res => res.ok ? res.json() : null)
          .then(song => {
            const text = song ? `${song.title} - ${song.artist}` : 'Song not found in library';
            if (!isPlaying && idleSelectSub) idleSelectSub.textContent = text;
            if (deckTitle) deckTitle.textContent = text;
          })
          .catch(() => {});
      } else {
        if (idleSelectSub) idleSelectSub.textContent = 'Enter Song Number on Remote or Keypad';
        if (deckTitle) deckTitle.textContent = 'Ready - Dial Code or Pick Song';
      }
    } else {
      if (dialBuffer) {
        if (tvDialHud) tvDialHud.style.display = 'flex';
        if (tvDialDigits) tvDialDigits.textContent = padded;
        const num = parseInt(dialBuffer, 10);
        fetch(`/api/songmeta/${num}`)
          .then(res => res.ok ? res.json() : null)
          .then(song => {
            const text = song ? `${song.title} - ${song.artist}` : 'Song not found in library';
            if (tvDialTitle) tvDialTitle.textContent = text;
            if (deckTitle) deckTitle.textContent = text;
          })
          .catch(() => {});
      } else {
        if (tvDialHud) tvDialHud.style.display = 'none';
        if (deckTitle) deckTitle.textContent = 'Ready - Dial Code or Pick Song';
      }
    }
  }

  let lastDigitPressTime = 0;
  let lastDigitPressed = null;

  function onDigitPress(d) {
    try {
      if (TvNavigator.getContext() === 'settings' || TvNavigator.getContext() === 'qr' || TvNavigator.getContext() === 'score' || TvNavigator.getContext() === 'update' || TvNavigator.getContext() === 'media') {
        return;
      }

      if (d === undefined || d === null) return;
      const digitStr = String(d).trim();
      if (!/^[0-9]$/.test(digitStr)) return;

      const now = performance.now();
      // Guard against double-press / rapid bounce / dual-dispatch:
      // Same digit within 450ms is dropped as duplicate bounce/bridge echo.
      // Any digit within 120ms is dropped as impossible physical input rate.
      if (lastDigitPressed === digitStr && (now - lastDigitPressTime) < 450) {
        return;
      }
      if ((now - lastDigitPressTime) < 120) {
        return;
      }
      lastDigitPressTime = now;
      lastDigitPressed = digitStr;

      playNumberVoice(digitStr);
      // Visual flash on on-screen keypad button if rendered
      const btn = document.getElementById('tv-btn-digit-' + digitStr);
      if (btn) {
        btn.classList.remove('tv-key-pulse');
        void btn.offsetWidth;
        btn.classList.add('tv-key-pulse');
      }
      if (dialBuffer.length >= 6) dialBuffer = '';
      dialBuffer += digitStr;
      updateTvDialFromBuffer(dialBuffer);

      // Auto-commit timer: only fires when idle (not playing) AND user has typed
      // at least 5 digits so we don't commit a partial code too early.
      // When a song IS playing we never auto-commit — user must press OK/Enter to reserve.
      if (!isPlaying && dialBuffer.length >= 5) {
        if (dialAutoPlayTimer) clearTimeout(dialAutoPlayTimer);
        dialAutoPlayTimer = setTimeout(() => {
          dialCommit();
        }, 4000); // 4 s gives enough time to type the last digit before auto-play
      } else {
        // Cancel any stale timer if now playing or buffer still too short
        if (dialAutoPlayTimer) { clearTimeout(dialAutoPlayTimer); dialAutoPlayTimer = null; }
      }
    } catch (e) {
      console.warn('onDigitPress error:', e);
    }
  }

  // isExplicit=true  → called by OK/Enter button press (can reserve while playing)
  // isExplicit=false → called by auto-timer (only loads on idle, NEVER auto-reserves)
  function dialCommit(isExplicit) {
    lastDigitPressTime = 0;
    lastDigitPressed = null;
    if (dialAutoPlayTimer) clearTimeout(dialAutoPlayTimer);
    dialAutoPlayTimer = null;
    if (tvDialHud) tvDialHud.style.display = 'none';

    if (dialBuffer) {
      const num = parseInt(dialBuffer, 10);
      dialBuffer = '';
      if (isPlaying) {
        // Only reserve when user explicitly pressed OK — never on auto-timer!
        if (!isExplicit) {
          // Auto-timer fired while playing: just cancel quietly
          return;
        }
        // Explicit OK/Enter while playing → reserve into queue
        fetch(`/api/song/${num}`)
          .then(res => res.ok ? res.json() : null)
          .then(song => {
            const title = song ? `${song.title} - ${song.artist}` : ('#' + num);
            showToast('✓ Reserved ' + title);
          })
          .catch(() => showToast('✓ Reserved #' + num));

        fetch('/api/command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'reserve', num: num })
        })
        .then(() => syncQueueWithServer())
        .catch(() => {});
      } else {
        // Idle screen: load and play immediately
        loadSong(num);
      }
    }
  }

  function dialCancel() {
    lastDigitPressTime = 0;
    lastDigitPressed = null;
    if (dialAutoPlayTimer) clearTimeout(dialAutoPlayTimer);
    dialAutoPlayTimer = null;
    dialBuffer = '';
    if (tvDialHud) tvDialHud.style.display = 'none';

    // Always reset all digit displays to 000000
    const deckDigits = document.getElementById('tv-deck-digits');
    if (deckDigits) deckDigits.textContent = '000000';
    if (idleSelectDigits) idleSelectDigits.textContent = '000000';
    if (!isPlaying) {
      if (idleSelectSub) idleSelectSub.textContent = 'Enter Song Number on Remote or Keypad';
    }
  }

  // --- 9. Modals & QR & Resource Download ---
  let isDownloadActive = false;

  // Helper functions to cleanly control Stage Controller visibility
  function closeTvDeckDirectly() {
    isTvDeckOpen = false;
    const deck = document.getElementById('tv-stage-deck');
    const arrow = document.getElementById('tv-deck-arrow');
    const toggleBtn = document.getElementById('tv-deck-toggle-btn');
    if (deck) {
      deck.classList.add('tv-deck-hidden');
      deck.setAttribute('inert', '');
    }
    if (arrow) {
      arrow.textContent = '▲';
      arrow.classList.add('deck-arrow-anim');
    }
    if (toggleBtn) {
      toggleBtn.title = 'Open Keypad';
    }
  }

  function restoreTvDeckWrapper() {
    const deckWrapper = document.getElementById('tv-deck-wrapper');
    if (deckWrapper) {
      deckWrapper.classList.remove('deck-force-hidden');
      deckWrapper.style.display = '';
      deckWrapper.style.pointerEvents = '';
      deckWrapper.style.visibility = '';
    }
  }

  function closeAllModals() {
    // Block closing if download is in progress
    if (isDownloadActive || (typeof isAppUpdating !== 'undefined' && isAppUpdating)) return;
    dismissScoreModal();
    document.querySelectorAll('.singhub-modal').forEach(m => m.style.display = 'none');
    document.body.classList.remove('settings-open');
    TvNavigator.clearFocus();
    restoreTvDeckWrapper();
    const deck = document.getElementById('tv-stage-deck');
    if (deck) {
      if (isTvDeckOpen) {
        deck.removeAttribute('inert');
        const activeTabBtn = document.querySelector('.tv-deck-tab.active');
        const activeTabId = activeTabBtn ? activeTabBtn.id : 'tv-tab-btn-pad';
        if (activeTabId === 'tv-tab-btn-search') {
          TvNavigator.searchSongIdx = -1;
          const searchInput = document.getElementById('tv-deck-search-input');
          TvNavigator.setFocus(searchInput || document.getElementById('tv-tab-btn-search'));
        } else if (activeTabId === 'tv-tab-btn-queue') {
          TvNavigator.queueIdx = -1;
          TvNavigator.setFocus(document.getElementById('tv-tab-btn-queue'));
        } else {
          TvNavigator.padRow = 1;
          TvNavigator.padCol = 1;
          const el = document.getElementById('tv-btn-digit-2');
          if (el) TvNavigator.setFocus(el);
        }
      } else {
        deck.setAttribute('inert', '');
      }
    }
  }

  let downloadCountdownTimer = null;

  function checkResourceStatus(isAutoPrompt) {
    let status = null;
    if (window.SinghubNative && window.SinghubNative.getResourceStatusNative) {
      try {
        status = JSON.parse(window.SinghubNative.getResourceStatusNative());
      } catch (e) {}
    }

    const missingBanner = document.getElementById('res-missing-banner');
    if (missingBanner) missingBanner.style.display = 'none';

    const statusVal = document.getElementById('tv-res-status-val');
    const statusSub = document.getElementById('tv-res-status-sub');

    fetch('/api/stats', { headers: AUTH_HEADERS })
      .then(r => r.json())
      .then(data => {
        const cnt = (data && data.count) || (status && status.songCount) || 40000;
        if (statusVal) {
          statusVal.textContent = 'READY';
          statusVal.style.color = '#00f59b';
        }
        if (statusSub) {
          statusSub.textContent = `${cnt.toLocaleString()} songs loaded (Built-in Offline)`;
        }
      })
      .catch(() => {
        if (statusVal) {
          statusVal.textContent = 'READY';
          statusVal.style.color = '#00f59b';
        }
        if (statusSub) {
          const cnt = (status && status.songCount) || 40000;
          statusSub.textContent = `${cnt.toLocaleString()} songs loaded (Built-in Offline)`;
        }
      });

    updateMainResourceUI(true);
  }

  function updateMainResourceUI(isReady, statusMsg) {
    const badge = document.getElementById('dl-badge-main');
    const statusText = document.getElementById('dl-status-main');
    const fill = document.getElementById('dl-fill-main');
    if (badge) {
      badge.textContent = isReady ? 'READY' : 'MISSING';
      badge.style.background = isReady ? 'rgba(0,245,155,0.2)' : 'rgba(255,59,48,0.2)';
      badge.style.color = isReady ? '#00f59b' : '#ff6b6b';
    }
    if (statusText) {
      statusText.textContent = statusMsg || (isReady ? 'Installed and ready to play' : 'Waiting to download...');
      statusText.style.color = isReady ? '#00f59b' : '#94a3b8';
    }
    if (fill && isReady) {
      fill.style.width = '100%';
    }
  }

  function updateDownloadModalRow(key, isPresent) {
    // Kept for backward compatibility
  }

  function confirmFirstTimeDownload() {
    // Hide only the first-time modal, then open download modal directly
    const ftModal = document.getElementById('modal-first-time-dl');
    if (ftModal) ftModal.style.display = 'none';
    const modal = document.getElementById('modal-download');
    if (modal) {
      modal.style.display = 'flex';
      const cDown = document.getElementById('dl-complete-countdown');
      if (cDown) cDown.style.display = 'none';
      const errBanner = document.getElementById('dl-error-banner');
      if (errBanner) errBanner.style.display = 'none';
    }
    startResourceDownload();
  }

  function openDownloadModal() {
    if (!isDownloadActive) {
      document.querySelectorAll('.singhub-modal').forEach(m => m.style.display = 'none');
    }
    const modal = document.getElementById('modal-download');
    if (modal) {
      modal.style.display = 'flex';
      const cDown = document.getElementById('dl-complete-countdown');
      if (cDown) cDown.style.display = 'none';
      const errBanner = document.getElementById('dl-error-banner');
      if (errBanner) errBanner.style.display = 'none';
      checkResourceStatus(false);
    }
  }

  function startResourceDownload() {
    if (downloadCountdownTimer) {
      clearInterval(downloadCountdownTimer);
      downloadCountdownTimer = null;
    }

    const startBtn = document.getElementById('dl-btn-start');
    const errBanner = document.getElementById('dl-error-banner');
    const cDown = document.getElementById('dl-complete-countdown');

    if (errBanner) errBanner.style.display = 'none';
    if (cDown) cDown.style.display = 'none';

    if (startBtn) {
      startBtn.style.display = 'none';
      startBtn.textContent = '⬇ Download Resources';
    }

    const bar = document.getElementById('dl-bar-main');
    const fill = document.getElementById('dl-fill-main');
    const statusText = document.getElementById('dl-status-main');
    const badge = document.getElementById('dl-badge-main');
    if (bar) bar.style.display = 'block';
    if (fill) fill.style.width = '0%';
    if (statusText) {
      statusText.textContent = 'Connecting and downloading resources...';
      statusText.style.color = '#00e5ff';
    }
    if (badge) {
      badge.textContent = '0%';
      badge.style.background = 'rgba(0,229,255,0.2)';
      badge.style.color = '#00e5ff';
    }

    if (window.SinghubNative && window.SinghubNative.startDownloadResourcesNative) {
      isDownloadActive = true;
      window.SinghubNative.startDownloadResourcesNative();
    } else {
      showToast('Downloading requires Android TV host mode');
    }
  }

  function cancelResourceDownload() {
    isDownloadActive = false;
    const startBtn = document.getElementById('dl-btn-start');
    if (startBtn) startBtn.style.display = 'block';

    if (window.SinghubNative && window.SinghubNative.cancelDownloadResourcesNative) {
      window.SinghubNative.cancelDownloadResourcesNative();
    }
  }

  function openQrModal() {
    const modal = document.getElementById('modal-qr');
    if (modal) {
      const isOpen = (modal.style.display && modal.style.display !== 'none');
      if (isOpen) {
        closeAllModals();
      } else {
        closeAllModals();
        modal.style.display = 'flex';
        const deck = document.getElementById('tv-stage-deck');
        if (deck) deck.setAttribute('inert', '');
        generateQr();
      }
    }
  }

  function generateQr() {
    const ip = (window.SinghubNative && window.SinghubNative.getDeviceIp) ? window.SinghubNative.getDeviceIp() : window.location.hostname;
    const port = (window.SinghubNative && window.SinghubNative.getServerPort) ? window.SinghubNative.getServerPort() : 8000;
    const token = (window.SinghubNative && window.SinghubNative.getServerAuthToken) ? window.SinghubNative.getServerAuthToken() : '';
    const remoteUrl = token ? `http://${ip}:${port}/remote.html?auth=${token}` : `http://${ip}:${port}/remote.html`;

    const urlText = document.getElementById('qr-url-text');
    if (urlText) urlText.textContent = remoteUrl;

    const qrContainer = document.getElementById('qr-container');
    if (qrContainer && window.QRCode) {
      qrContainer.innerHTML = '';
      new QRCode(qrContainer, {
        text: remoteUrl,
        width: 190,
        height: 190,
        colorDark: '#070a13',
        colorLight: '#ffffff'
      });
    }
  }

  // --- 9b. In-App Auto-Updater (Option 3 - Website Check) ---
  let currentUpdateInfo = null;
  let isAppUpdating = false;

  function checkForUpdates(isManual) {
    const statusVal = document.getElementById('tv-update-status-val');
    const statusSub = document.getElementById('tv-update-status-sub');
    if (isManual) {
      if (statusVal) {
        statusVal.textContent = 'CHECKING...';
        statusVal.style.color = 'var(--accent-cyan)';
      }
      if (statusSub) {
        statusSub.textContent = 'Connecting to GitHub & update servers...';
      }
    }

    if (window.SinghubNative && window.SinghubNative.checkAppUpdateNative) {
      window.SinghubNative.checkAppUpdateNative(isManual === true);
      return;
    }

    // Standalone Web Browser Fallback: Check website manifest, then GitHub releases API
    const curCode = (window.SinghubNative && window.SinghubNative.getAppVersionCode) ? window.SinghubNative.getAppVersionCode() : 8;
    const curVer = (window.SinghubNative && window.SinghubNative.getAppVersionName) ? window.SinghubNative.getAppVersionName() : '2.0.5';

    fetch('https://singhub.zoryva.me/version.json?t=' + Date.now())
      .then(r => r.ok ? r.json() : null)
      .catch(() => null)
      .then(data => {
        if (data && data.targets) {
          const tvTarget = (data.targets && (data.targets.tv || data.targets.host)) || data;
          const isAvail = (tvTarget.versionCode > curCode);
          onUpdateCheckResult({
            isAvailable: isAvail,
            currentVersion: curVer,
            latestVersion: tvTarget.versionName || data.versionName,
            latestCode: tvTarget.versionCode || data.versionCode,
            title: data.title || 'Karaoke Studio Update',
            changelog: Array.isArray(data.changelog) ? data.changelog.join('\n• ') : (data.changelog || ''),
            apkUrl: tvTarget.apkUrl || '',
            apkSize: tvTarget.apkSize || 0
          }, isManual);
          return;
        }

        // Fallback: Check GitHub Releases API directly
        return fetch('https://api.github.com/repos/zoryvaxcinema-source/SING-HUB/releases/latest')
          .then(r => r.ok ? r.json() : null)
          .then(gh => {
            if (!gh) throw new Error('Offline or no releases found');
            const relVer = (gh.tag_name || '2.0.4').replace(/^[vV]/, '');
            const assets = gh.assets || [];
            const tvAsset = assets.find(a => a.name.toLowerCase().includes('tv') && a.name.endsWith('.apk')) || assets[0];
            const isAvail = (relVer !== curVer && relVer > curVer);
            onUpdateCheckResult({
              isAvailable: isAvail,
              currentVersion: curVer,
              latestVersion: relVer,
              latestCode: 7,
              title: gh.name || ('Karaoke Studio v' + relVer),
              changelog: gh.body || '',
              apkUrl: tvAsset ? tvAsset.browser_download_url : '',
              apkSize: tvAsset ? tvAsset.size : 0
            }, isManual);
          });
      })
      .catch(err => {
        onUpdateCheckResult({ isAvailable: false, error: err.message }, isManual);
      });
  }

  function onUpdateCheckResult(info, isManual) {
    if (!info) return;
    currentUpdateInfo = info;

    const statusVal = document.getElementById('tv-update-status-val');
    const statusSub = document.getElementById('tv-update-status-sub');
    const topBadge = document.getElementById('top-update-badge');

    if (info.isAvailable) {
      if (statusVal) {
        statusVal.textContent = 'UPDATE NOW ›';
        statusVal.style.color = '#00e5ff';
      }
      if (statusSub) {
        statusSub.textContent = `New version v${info.latestVersion} available! Click to install`;
      }
      if (topBadge) {
        topBadge.style.display = 'inline-block';
        topBadge.textContent = `⚡ UPDATE (v${info.latestVersion})`;
      }
      if (isManual) {
        openUpdateModal(info);
      }
    } else {
      if (topBadge) topBadge.style.display = 'none';
      if (statusVal) {
        statusVal.textContent = 'UP TO DATE';
        statusVal.style.color = '#ffffff';
        statusVal.style.background = 'rgba(255, 255, 255, 0.22)';
        statusVal.style.border = '1px solid rgba(255, 255, 255, 0.4)';
      }
      if (statusSub) {
        statusSub.textContent = info.error ? (`Cannot reach update servers (offline)`) : (`Current: v${info.currentVersion || '2.1.0'} is up to date!`);
        statusSub.style.color = '#ffffff';
      }
    }
  }

  function openUpdateModal(info) {
    if (!info) info = currentUpdateInfo;
    const modal = document.getElementById('modal-tv-update');
    if (!modal) return;
    if (!info) {
      checkForUpdates(true);
      return;
    }

    const title = document.getElementById('tv-update-modal-title');
    const sub = document.getElementById('tv-update-modal-sub');
    const curVer = document.getElementById('tv-update-cur-ver');
    const newVer = document.getElementById('tv-update-new-ver');
    const sizeVal = document.getElementById('tv-update-size-val');
    const notes = document.getElementById('tv-update-changelog-text');

    if (title) title.textContent = info.title || 'New Update Available!';
    if (sub) sub.textContent = `Karaoke Studio v${info.latestVersion || '2.0.4'} is ready to install`;
    if (curVer) curVer.textContent = 'v' + (info.currentVersion || '2.0.4').replace(/^v/, '');
    if (newVer) newVer.textContent = 'v' + (info.latestVersion || '2.0.4').replace(/^v/, '');

    if (sizeVal) {
      if (info.apkSize && info.apkSize > 0) {
        const mb = (info.apkSize / (1024 * 1024)).toFixed(1);
        sizeVal.textContent = mb + ' MB';
      } else {
        sizeVal.textContent = '~728 MB';
      }
    }

    if (notes) {
      if (info.changelog) {
        const lines = info.changelog.split('\n').filter(Boolean);
        notes.innerHTML = lines.map(l => l.startsWith('•') ? l : ('• ' + l)).join('<br>');
      } else {
        notes.textContent = '• Stability and performance improvements\n• Audio engine and stage updates';
      }
    }

    const pBox = document.getElementById('tv-update-progress-box');
    if (pBox) pBox.style.display = 'none';

    const actIdle = document.getElementById('tv-update-actions-idle');
    const actDl = document.getElementById('tv-update-actions-downloading');
    const actInst = document.getElementById('tv-update-actions-install');
    if (actIdle) actIdle.style.display = 'flex';
    if (actDl) actDl.style.display = 'none';
    if (actInst) actInst.style.display = 'none';

    modal.style.display = 'flex';
    toggleTvDeck(false);
    const deckWrapper = document.getElementById('tv-deck-wrapper');
    if (deckWrapper) {
      deckWrapper.classList.add('deck-force-hidden');
      deckWrapper.style.display = 'none';
    }
    TvNavigator.updateIdx = 0;
    const updateNowBtn = document.getElementById('tv-btn-update-now');
    if (updateNowBtn) TvNavigator.setFocus(updateNowBtn);
  }

  function closeUpdateModal() {
    if (isAppUpdating) return;
    const modal = document.getElementById('modal-tv-update');
    if (modal) modal.style.display = 'none';
    TvNavigator.clearFocus();
    const settingsModal = document.getElementById('modal-tv-settings');
    if (settingsModal && settingsModal.style.display === 'flex') {
      TvNavigator.setFocus(document.getElementById('tv-update-status-row'));
    } else {
      const deckWrapper = document.getElementById('tv-deck-wrapper');
      if (deckWrapper) {
        deckWrapper.classList.remove('deck-force-hidden');
        deckWrapper.style.display = '';
      }
    }
  }

  function startUpdateDownload() {
    isAppUpdating = true;
    const pBox = document.getElementById('tv-update-progress-box');
    if (pBox) pBox.style.display = 'block';

    const actIdle = document.getElementById('tv-update-actions-idle');
    const actDl = document.getElementById('tv-update-actions-downloading');
    const actInst = document.getElementById('tv-update-actions-install');
    if (actIdle) actIdle.style.display = 'none';
    if (actDl) actDl.style.display = 'flex';
    if (actInst) actInst.style.display = 'none';

    const cancelBtn = document.getElementById('tv-btn-update-cancel');
    if (cancelBtn) {
      TvNavigator.updateIdx = 0;
      TvNavigator.setFocus(cancelBtn);
    }

    const apkUrl = currentUpdateInfo ? currentUpdateInfo.apkUrl : '';
    if (window.SinghubNative && window.SinghubNative.startAppUpdateNative) {
      window.SinghubNative.startAppUpdateNative(apkUrl);
    }
  }

  function onUpdateProgress(percent, downloadedBytes, totalBytes) {
    const fill = document.getElementById('tv-update-progress-fill');
    const pct = document.getElementById('tv-update-p-pct');
    const bytes = document.getElementById('tv-update-p-bytes');
    const status = document.getElementById('tv-update-p-status');

    if (fill) fill.style.width = percent + '%';
    if (pct) pct.textContent = percent + '%';
    if (status) status.textContent = `Downloading update (${percent}%)...`;

    if (bytes) {
      const dlMb = (downloadedBytes / (1024 * 1024)).toFixed(1);
      const totMb = (totalBytes / (1024 * 1024)).toFixed(1);
      bytes.textContent = `${dlMb} MB / ${totMb} MB`;
    }
  }

  function onUpdateComplete() {
    isAppUpdating = false;
    const status = document.getElementById('tv-update-p-status');
    if (status) {
      status.textContent = '✓ Download Complete! Launching Package Installer...';
      status.style.color = '#00f59b';
    }

    const fill = document.getElementById('tv-update-progress-fill');
    if (fill) fill.style.width = '100%';

    const actDl = document.getElementById('tv-update-actions-downloading');
    const actInst = document.getElementById('tv-update-actions-install');
    if (actDl) actDl.style.display = 'none';
    if (actInst) actInst.style.display = 'flex';

    const instBtn = document.getElementById('tv-btn-update-install');
    if (instBtn) {
      TvNavigator.updateIdx = 0;
      TvNavigator.setFocus(instBtn);
    }

    setTimeout(() => {
      installDownloadedApk();
    }, 600);
  }

  function onUpdateFailed(errorMsg) {
    isAppUpdating = false;
    const status = document.getElementById('tv-update-p-status');
    if (status) {
      status.textContent = 'Download error: ' + (errorMsg || 'Failed to download APK');
      status.style.color = '#ef4444';
    }

    const actIdle = document.getElementById('tv-update-actions-idle');
    const actDl = document.getElementById('tv-update-actions-downloading');
    if (actIdle) actIdle.style.display = 'flex';
    if (actDl) actDl.style.display = 'none';

    const retryBtn = document.getElementById('tv-btn-update-now');
    if (retryBtn) {
      retryBtn.innerHTML = 'RETRY DOWNLOAD';
      TvNavigator.updateIdx = 0;
      TvNavigator.setFocus(retryBtn);
    }
  }

  function cancelUpdateDownload() {
    isAppUpdating = false;
    if (window.SinghubNative && window.SinghubNative.cancelAppUpdateNative) {
      window.SinghubNative.cancelAppUpdateNative();
    }
    closeUpdateModal();
  }

  function installDownloadedApk() {
    if (window.SinghubNative && window.SinghubNative.installAppUpdateNative) {
      window.SinghubNative.installAppUpdateNative();
    }
  }

  function switchNextBgv() {
    const bgv = document.getElementById('bg-video');
    if (!bgv) return;

    fetch('/api/bgv/next', { headers: AUTH_HEADERS })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data && data.url) {
          playBgVideoUrl(data.url);
        } else {
          playBgVideoUrl('/video?t=' + Date.now());
        }
      })
      .catch(() => {
        playBgVideoUrl('/video?t=' + Date.now());
      });
  }

  function playBgVideoUrl(url) {
    const bgv = document.getElementById('bg-video');
    const bgp = document.getElementById('bg-photo');
    if (!bgv) return;

    if (bgp) bgp.style.display = 'none';
    bgv.style.display = 'block';

    // Enforce muted settings so Chromium/Android WebView autoplay never gets blocked
    bgv.muted = true;
    bgv.defaultMuted = true;
    bgv.volume = 0;
    bgv.loop = true;
    bgv.playsInline = true;
    bgv.setAttribute('playsinline', '');
    bgv.setAttribute('webkit-playsinline', '');

    if (bgv.getAttribute('data-active-url') === url && !bgv.paused && bgv.currentTime > 0) {
      return;
    }
    bgv.setAttribute('data-active-url', url);
    bgv.src = url;
    bgv.load();
    const p = bgv.play();
    if (p !== undefined) {
      p.catch(err => {
        console.warn('BGV play deferred, will resume on interaction:', err);
        setTimeout(() => {
          if (bgv) {
            bgv.muted = true;
            bgv.play().catch(() => {});
          }
        }, 800);
      });
    }
  }

  function formatBytes(bytes) {
    if (!bytes || bytes <= 0) return '0 B';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  }

  // All notification badges, toasts, and overlays on TV Stage are completely disabled per user request
  function showToast(msg) {
    // Suppressed on TV Stage
  }

  function updateDeckPitchTempoBadges() {
    const kVal = document.getElementById('tv-deck-key-val');
    if (kVal) kVal.textContent = keyShift > 0 ? ('+' + keyShift) : keyShift;
    const tVal = document.getElementById('tv-deck-tempo-val');
    if (tVal) tVal.textContent = tempoShift > 0 ? ('+' + tempoShift) : tempoShift;
  }

  function shiftKey(delta) {
    keyShift = Math.max(-6, Math.min(6, keyShift + delta));
    if (window.SinghubNative && window.SinghubNative.setKeyShiftNative) {
      window.SinghubNative.setKeyShiftNative(keyShift);
    }
    const wm = document.getElementById('web-midi-player');
    if (wm && wm.player && typeof wm.player.isPlaying === 'function' && wm.player.isPlaying() && currentSong && currentSong.num) {
      const curT = wm.currentTime || 0;
      wm.src = `/api/midi/${currentSong.num}?key=${keyShift}&tempo=${tempoShift}&melody=${currentSettings.melodyLevel || 'HIGH'}&t=${Date.now()}`;
      try {
        if (typeof wm.start === 'function') {
          wm.start();
          if (curT > 0 && typeof wm.seek === 'function') wm.seek(curT);
        }
      } catch (e) {}
    }
    updateDeckPitchTempoBadges();
    broadcastState();
  }

  function shiftTempo(delta) {
    tempoShift = Math.max(-10, Math.min(10, tempoShift + delta));
    if (window.SinghubNative && window.SinghubNative.setTempoShiftNative) {
      window.SinghubNative.setTempoShiftNative(tempoShift);
    }
    const wm = document.getElementById('web-midi-player');
    if (wm && wm.player && typeof wm.player.isPlaying === 'function' && wm.player.isPlaying() && currentSong && currentSong.num) {
      const curT = wm.currentTime || 0;
      wm.src = `/api/midi/${currentSong.num}?key=${keyShift}&tempo=${tempoShift}&melody=${currentSettings.melodyLevel || 'HIGH'}&t=${Date.now()}`;
      try {
        if (typeof wm.start === 'function') {
          wm.start();
          if (curT > 0 && typeof wm.seek === 'function') wm.seek(curT);
        }
      } catch (e) {}
    }
    updateDeckPitchTempoBadges();
    broadcastState();
  }

  let masterVolume = 100;
  function shiftVolume(delta) {
    masterVolume = Math.max(0, Math.min(100, masterVolume + delta));
    currentSettings.volume = masterVolume;
    const volVal = document.getElementById('tv-volume-val');
    if (volVal) volVal.textContent = masterVolume + '% ›';
    if (window.SinghubNative && window.SinghubNative.setVolumeNative) {
      window.SinghubNative.setVolumeNative(masterVolume);
    }
    if (mp3Player) {
      try { mp3Player.volume = masterVolume / 100; } catch (e) {}
    }
    const wm = document.getElementById('web-midi-player');
    if (wm) {
      try {
        if (typeof wm.volume !== 'undefined') wm.volume = masterVolume / 100;
        if (wm.player && wm.player.output && typeof wm.player.output.volume !== 'undefined') {
          wm.player.output.volume = masterVolume / 100;
        }
      } catch (e) {}
    }
    try {
      localStorage.setItem('singhub_tv_settings', JSON.stringify(currentSettings));
    } catch (e) {}
    broadcastState();
  }

  function applyProjMode(mode) {
    projMode = mode || '16:9';
    currentSettings.projMode = projMode;
    const bgStage = document.getElementById('bg-stage');
    const osd = document.getElementById('singhub-osd');
    const bgVideo = document.getElementById('bg-video');
    const bgPhoto = document.getElementById('bg-photo');

    if (projMode === '4:3') {
      if (bgStage) {
        bgStage.style.maxWidth = 'calc(100vh * 4 / 3)';
        bgStage.style.margin = '0 auto';
        bgStage.style.overflow = 'hidden';
      }
      if (osd) {
        osd.style.maxWidth = 'calc(100vh * 4 / 3)';
        osd.style.margin = '0 auto';
      }
      if (bgVideo) bgVideo.style.objectFit = 'contain';
      if (bgPhoto) bgPhoto.style.objectFit = 'contain';
    } else if (projMode === 'FILL') {
      if (bgStage) {
        bgStage.style.maxWidth = '100vw';
        bgStage.style.margin = '0';
      }
      if (osd) {
        osd.style.maxWidth = '100vw';
        osd.style.margin = '0';
      }
      if (bgVideo) bgVideo.style.objectFit = 'cover';
      if (bgPhoto) bgPhoto.style.objectFit = 'cover';
    } else { // '16:9'
      if (bgStage) {
        bgStage.style.maxWidth = '100vw';
        bgStage.style.margin = '0';
      }
      if (osd) {
        osd.style.maxWidth = '100vw';
        osd.style.margin = '0';
      }
      if (bgVideo) bgVideo.style.objectFit = 'cover';
      if (bgPhoto) bgPhoto.style.objectFit = 'cover';
    }
  }

  // --- 10. Settings, Audio Modes & State Sync ---
  let melodyLevel = 'HIGH';
  let mpxMode = 'STEREO';
  let projMode = '16:9';
  let playMode = 'CONTINUOUS';

  let currentSettings = {
    lyricColor: '#00e5ff',
    lyricAlign: 'center',
    lyricSize: 'xlarge',
    lyricOutline: '2',
    lyricShadow: true,
    lyricFont: 'Sans',
    scoreMode: 'RANDOM',
    scoreDifficulty: 'MEDIUM',
    fanfare: 'MID',
    bgvMode: 'video',
    continuousVideo: true,
    projMode: '16:9',
    melodyLevel: 'HIGH',
    mpxMode: 'STEREO',
    playMode: 'CONTINUOUS',
    volume: 100,
    soundfont: 'bundled'
  };

  function applySettings(s) {
    if (!s) return;

    // Only reload soundfont if explicitly provided and ACTUALLY DIFFERENT from current
    if (s.soundfont || s.activeSoundfont) {
      const sfName = s.soundfont || s.activeSoundfont;
      const isBundled = (!sfName || sfName === 'bundled' || sfName === 'default' || sfName === 'undefined' || sfName.includes('Built-in') || sfName.includes('SAM5504B'));
      const targetSf = isBundled ? 'bundled' : sfName;
      if (targetSf !== currentSettings.soundfont) {
        currentSettings.soundfont = targetSf;
        const wm = document.getElementById('web-midi-player');
        if (wm) {
          wm.setAttribute('sound-font', targetSf === 'bundled' ? '/sound/web_gm.sf2' : ('/api/soundfont/active?t=' + Date.now()));
        }
        if (typeof updateActiveMediaLabels === 'function') updateActiveMediaLabels();
      }
    }

    Object.assign(currentSettings, s);

    if (s.melodyLevel) {
      melodyLevel = s.melodyLevel;
      if (window.SinghubNative && window.SinghubNative.setMelodyLevelNative) {
        window.SinghubNative.setMelodyLevelNative(melodyLevel);
      }
      // Live scale web synth notes if active
      const wm = document.getElementById('web-midi-player');
      if (wm && wm.noteSequence && Array.isArray(wm.noteSequence.notes)) {
        const factor = melodyLevel === 'OFF' ? 0.0 : (melodyLevel === 'LOW' ? 0.30 : (melodyLevel === 'MID' ? 0.65 : 1.0));
        wm.noteSequence.notes.forEach(n => {
          // Match melody track: Channel 0, or flute/vocal programs (72-74), or instrument 0
          if (n.channel === 0 || n.instrument === 0 || n.program === 0 || n.program === 72 || n.program === 73 || n.program === 74) {
            if (n._origVel === undefined) n._origVel = n.velocity || 80;
            n.velocity = Math.round(n._origVel * factor);
          }
        });
      }
    }

    if (s.mpxMode) {
      mpxMode = s.mpxMode;
      if (window.SinghubNative && window.SinghubNative.setMpxModeNative) {
        window.SinghubNative.setMpxModeNative(mpxMode);
      }
    }

    if (s.volume !== undefined) {
      masterVolume = Math.max(0, Math.min(100, Number(s.volume) || 0));
      currentSettings.volume = masterVolume;
      if (window.SinghubNative && window.SinghubNative.setVolumeNative) {
        window.SinghubNative.setVolumeNative(masterVolume);
      }
      if (mp3Player) {
        try { mp3Player.volume = masterVolume / 100; } catch (e) {}
      }
    }

    if (s.projMode) {
      applyProjMode(s.projMode);
    }

    if (s.playMode) playMode = s.playMode;

    if (s.bgvMode) {
      currentSettings.bgvMode = s.bgvMode;
      const bgv = document.getElementById('bg-video');
      const bgp = document.getElementById('bg-photo');
      if (s.bgvMode === 'video') {
        if (bgv) {
          bgv.style.display = 'block';
          bgv.muted = true;
          bgv.play().catch(() => {});
        }
        if (bgp) bgp.style.display = 'none';
      } else if (s.bgvMode === 'photo') {
        if (bgv) {
          bgv.pause();
          bgv.style.display = 'none';
        }
        if (bgp) {
          bgp.style.display = 'block';
          bgp.src = '/api/bgphoto/random?t=' + Date.now();
        }
      } else {
        if (bgv) {
          bgv.pause();
          bgv.style.display = 'none';
        }
        if (bgp) bgp.style.display = 'none';
      }
    }

    // Apply Dynamic Lyric Styling (Eliminating interior letter skeleton lines)
    let dynStyle = document.getElementById('dynamic-singhub-styles');
    if (!dynStyle) {
      dynStyle = document.createElement('style');
      dynStyle.id = 'dynamic-singhub-styles';
      document.head.appendChild(dynStyle);
    }

    const color = s.lyricColor || currentSettings.lyricColor || '#00e5ff';
    const stroke = (s.lyricOutline !== undefined) ? s.lyricOutline : (currentSettings.lyricOutline || '2');
    const lyricSizeName = s.lyricSize || currentSettings.lyricSize || 'xlarge';
    const fontSize = lyricSizeName === 'normal' ? '46px' : (lyricSizeName === 'large' ? '56px' : '68px');
    const lyricAlignName = s.lyricAlign || currentSettings.lyricAlign || 'center';
    const align = lyricAlignName === 'left' ? 'flex-start' : (lyricAlignName === 'right' ? 'flex-end' : 'center');
    const textAlign = lyricAlignName === 'left' ? 'left' : (lyricAlignName === 'right' ? 'right' : 'center');
    const hasShadow = (s.lyricShadow !== undefined ? s.lyricShadow : currentSettings.lyricShadow) !== false;
    const fontType = s.lyricFont || currentSettings.lyricFont || 'Sans';
    // Android TV font stacks: include embedded @font-face and Android-native aliases alongside common names
    const font = fontType === 'PapaYo' ? "'PapaYo', 'Comic Sans MS', 'Chalkboard SE', casual, cursive, sans-serif" :
                 fontType === 'Proxima' ? "'Proxima', 'Proxima Nova', 'Trebuchet MS', sans-serif-medium, sans-serif-condensed, sans-serif" :
                 fontType === 'Impact' ? "Impact, 'Arial Black', sans-serif-black, sans-serif-condensed, sans-serif" :
                 fontType === 'Neon' ? "'Orbitron', 'Audiowide', 'Courier New', 'Lucida Console', Monaco, monospace" :
                 fontType === 'Cursive' ? "'Dancing Script', 'Brush Script MT', 'Segoe Script', cursive" :
                 fontType === 'Serif' ? "'Noto Serif', 'Playfair Display', Georgia, 'Times New Roman', serif" :
                 (fontType.includes(',') || fontType.includes(' ')) ? fontType :
                 `${fontType}, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`;

    // Deep silhouette drop-shadow (operates on rendered alpha silhouette of the text,
    // guaranteeing ZERO interior lines or glyph artifacts)
    const strokeW = Math.max(0, parseFloat(stroke) || 0);
    const filters = [];
    if (strokeW > 0) {
      const blurR = Math.max(1, Math.round(strokeW * 1.5));
      filters.push(`drop-shadow(0 0 ${blurR}px rgba(0, 0, 0, 0.98))`);
    }
    if (hasShadow) {
      filters.push('drop-shadow(0 3px 8px rgba(0, 0, 0, 0.95))', 'drop-shadow(0 0 16px rgba(0, 0, 0, 0.85))');
    } else if (filters.length === 0) {
      filters.push('drop-shadow(0 2px 6px rgba(0, 0, 0, 0.85))');
    }
    const computedFilter = filters.join(' ');

    const lyricWeight = (fontType === 'Impact') ? 'normal' : (fontType === 'Sans' ? '700' : 'bold');

    dynStyle.innerHTML = `
      :root {
        --sung-color: ${color};
      }
      .lyric-row {
        justify-content: ${align} !important;
        text-align: ${textAlign} !important;
        font-family: ${font} !important;
        font-size: ${fontSize} !important;
        font-weight: ${lyricWeight} !important;
        -webkit-text-stroke: 0px transparent !important;
        text-shadow: none !important;
      }
      .lyric-line-text {
        font-family: ${font} !important;
        font-size: ${fontSize} !important;
        font-weight: ${lyricWeight} !important;
        -webkit-text-stroke: 0px transparent !important;
        paint-order: normal !important;
        text-shadow: none !important;
        filter: ${computedFilter} !important;
      }
      .syl-marker {
        -webkit-text-stroke: 0px transparent !important;
        text-shadow: none !important;
      }
    `;

    // Instantly force-apply styles directly onto active lyric DOM elements so changes show live with zero frame delay
    const tl = document.getElementById('lyric-top-line');
    const bl = document.getElementById('lyric-bottom-line');
    if (tl) {
      tl.style.fontFamily = font;
      tl.style.fontSize = fontSize;
      tl.style.fontWeight = lyricWeight;
      tl.style.justifyContent = align;
      tl.style.textAlign = textAlign;
    }
    if (bl) {
      bl.style.fontFamily = font;
      bl.style.fontSize = fontSize;
      bl.style.fontWeight = lyricWeight;
      bl.style.justifyContent = align;
      bl.style.textAlign = textAlign;
    }
    document.querySelectorAll('.lyric-line-text').forEach(el => {
      el.style.fontFamily = font;
      el.style.fontSize = fontSize;
      el.style.fontWeight = lyricWeight;
      el.style.webkitTextStroke = '0px transparent';
      el.style.textShadow = 'none';
      el.style.filter = computedFilter;
    });

    // Update TV Settings Drawer labels
    const sModeVal = document.getElementById('tv-score-mode-val');
    if (sModeVal) sModeVal.textContent = (currentSettings.scoreMode || 'RANDOM') + ' ›';

    const sDiffVal = document.getElementById('tv-score-diff-val');
    if (sDiffVal) sDiffVal.textContent = (currentSettings.scoreDifficulty || 'MEDIUM') + ' ›';

    const fanfareVal = document.getElementById('tv-fanfare-val');
    if (fanfareVal) fanfareVal.textContent = (currentSettings.fanfare || 'MID') + ' ›';

    const bgvVal = document.getElementById('tv-bgv-mode-val');
    if (bgvVal) bgvVal.textContent = (currentSettings.bgvMode || 'VIDEO').toUpperCase() + ' ›';

    const contVal = document.getElementById('tv-continuous-video-val');
    if (contVal) contVal.textContent = (currentSettings.continuousVideo !== false ? 'ON' : 'OFF') + ' ›';

    const projVal = document.getElementById('tv-proj-mode-val');
    if (projVal) projVal.textContent = projMode + ' ›';

    const alignVal = document.getElementById('tv-lyric-align-val');
    if (alignVal) alignVal.textContent = (currentSettings.lyricAlign || 'CENTER').toUpperCase() + ' ›';

    const colorDot = document.getElementById('tv-color-indicator');
    if (colorDot) colorDot.style.background = color;

    const sizeVal = document.getElementById('tv-lyric-size-val');
    if (sizeVal) sizeVal.textContent = (currentSettings.lyricSize || 'XLARGE').toUpperCase() + ' ›';

    const outVal = document.getElementById('tv-lyric-outline-val');
    if (outVal) outVal.textContent = stroke + '.0 ›';

    const shadowVal = document.getElementById('tv-lyric-shadow-val');
    if (shadowVal) shadowVal.textContent = (currentSettings.lyricShadow !== false ? 'ON' : 'OFF') + ' ›';

    const fontVal = document.getElementById('tv-lyric-font-val');
    if (fontVal) fontVal.textContent = (fontType || 'SANS').toUpperCase() + ' ›';
    const fontSub = document.getElementById('tv-lyric-font-sub');
    if (fontSub) fontSub.textContent = 'Font: ' + (fontType || 'Sans');

    const volVal = document.getElementById('tv-volume-val');
    if (volVal) volVal.textContent = masterVolume + '% ›';

    const melVal = document.getElementById('tv-melody-val');
    if (melVal) melVal.textContent = melodyLevel + ' ›';

    const mpxVal = document.getElementById('tv-mpx-val');
    if (mpxVal) mpxVal.textContent = mpxMode + ' ›';

    const playVal = document.getElementById('tv-play-mode-val');
    if (playVal) playVal.textContent = playMode + ' ›';

    try {
      localStorage.setItem('singhub_tv_settings', JSON.stringify(currentSettings));
    } catch (e) {}

    broadcastState();
  }

  function cycleSetting(key, options) {
    if (!options || options.length === 0) return;
    let cur = currentSettings[key];
    if (cur === undefined || cur === null) cur = options[0];
    let idx = options.findIndex(opt => String(opt).toLowerCase() === String(cur).toLowerCase());
    if (idx < 0) idx = 0;
    const nextVal = options[(idx + 1) % options.length];
    const update = {};
    update[key] = nextVal;
    applySettings(update);

    fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(update)
    }).catch(e => {});
  }

  function toggleMelody() {
    cycleSetting('melodyLevel', ['HIGH', 'MID', 'LOW', 'OFF']);
  }

  function toggleMpx() {
    cycleSetting('mpxMode', ['STEREO', 'LEFT', 'RIGHT']);
  }

  function toggleProj() {
    cycleSetting('projMode', ['16:9', 'FILL', '4:3']);
  }

  function cycleMode() {
    cycleSetting('playMode', ['CONTINUOUS', 'SINGLE', 'REPEAT', 'RANDOM']);
  }

  function rescanContent() {
    showToast('Rescanning device storage for songs...');
    fetch('/api/rescan')
      .then(res => res.json())
      .then(data => {
        showToast(`Scan complete: ${data.total || 0} songs loaded!`);
      })
      .catch(() => {
        showToast('Storage scan initiated');
      });
  }

  // --- Media & Soundfont Studio State & Handlers ---
  let currentMediaTab = 'bgv';
  let cachedMediaData = null;

  function updateActiveMediaLabels(forcedData) {
    const applyData = (data) => {
      if (!data) return;
      cachedMediaData = data;
      const bgvVal = document.getElementById('tv-active-bgv-val');
      const bgvSub = document.getElementById('tv-active-bgv-sub');
      if (bgvVal) bgvVal.textContent = (data.activeBgv || 'AUTO').toUpperCase() + ' ›';
      if (bgvSub) bgvSub.textContent = (data.activeBgv && data.activeBgv !== 'AUTO') ? ('Active: ' + data.activeBgv) : 'Active: Auto Shuffle';

      const photoVal = document.getElementById('tv-active-photo-val');
      const photoSub = document.getElementById('tv-active-photo-sub');
      if (photoVal) photoVal.textContent = (data.activePhoto || 'AUTO').toUpperCase() + ' ›';
      if (photoSub) photoSub.textContent = (data.activePhoto && data.activePhoto !== 'AUTO') ? ('Active: ' + data.activePhoto) : 'Active: Auto Slideshow';

      const sfVal = document.getElementById('tv-soundfont-val');
      const sfSub = document.getElementById('tv-soundfont-sub');
      const curSf = (data.activeSoundfont && data.activeSoundfont !== 'undefined') ? data.activeSoundfont : 'bundled';
      const isBundled = (curSf === 'bundled' || curSf === 'default' || curSf.includes('Built-in') || curSf.includes('SAM5504B'));
      if (sfVal) sfVal.textContent = (isBundled ? 'DEFAULT' : curSf.replace(/\.sf2$/i, '')).toUpperCase() + ' ›';
      if (sfSub) sfSub.textContent = isBundled ? 'Current: Built-in Dream SAM5504B' : ('Custom: ' + curSf);

      const bgvCnt = document.getElementById('tv-mtab-bgv-cnt');
      if (bgvCnt) bgvCnt.textContent = data.bgvs ? data.bgvs.length : 0;
      const photoCnt = document.getElementById('tv-mtab-photo-cnt');
      if (photoCnt) photoCnt.textContent = data.photos ? data.photos.length : 0;
      const sfCnt = document.getElementById('tv-mtab-sf-cnt');
      if (sfCnt) sfCnt.textContent = data.soundfonts ? data.soundfonts.length : 0;
    };

    if (forcedData) {
      applyData(forcedData);
    } else {
      fetch('/api/media/list', { headers: AUTH_HEADERS })
        .then(r => r.json())
        .then(applyData)
        .catch(() => {});
    }
  }

  function cycleActiveBgv() {
    fetch('/api/media/list', { headers: AUTH_HEADERS })
      .then(r => r.json())
      .then(data => {
        cachedMediaData = data;
        const options = ['AUTO'];
        if (data.bgvs) {
          data.bgvs.forEach(b => options.push(b.name));
        }
        const cur = data.activeBgv || 'AUTO';
        let curIdx = options.findIndex(opt => opt.toLowerCase() === cur.toLowerCase());
        if (curIdx < 0) curIdx = 0;
        const next = options[(curIdx + 1) % options.length];
        selectMediaFromTv('bgv', next);
      })
      .catch(() => showToast('Could not fetch BGV list'));
  }

  function cycleActivePhoto() {
    fetch('/api/media/list', { headers: AUTH_HEADERS })
      .then(r => r.json())
      .then(data => {
        cachedMediaData = data;
        const options = ['AUTO'];
        if (data.photos) {
          data.photos.forEach(p => options.push(p.name));
        }
        const cur = data.activePhoto || 'AUTO';
        let curIdx = options.findIndex(opt => opt.toLowerCase() === cur.toLowerCase());
        if (curIdx < 0) curIdx = 0;
        const next = options[(curIdx + 1) % options.length];
        selectMediaFromTv('photo', next);
      })
      .catch(() => showToast('Could not fetch photo list'));
  }

  function cycleSoundfont() {
    fetch('/api/media/list', { headers: AUTH_HEADERS })
      .then(r => r.json())
      .then(data => {
        cachedMediaData = data;
        const options = ['bundled'];
        if (data.soundfonts && data.soundfonts.length > 0) {
          data.soundfonts.forEach(s => {
            const isBundled = s.bundled || s.path === 'bundled' || (s.name && s.name.includes('Built-in'));
            if (!isBundled && s.name && s.name !== 'bundled' && s.name !== 'default.sf2') {
              options.push(s.name);
            }
          });
        }
        let cur = (data.activeSoundfont && data.activeSoundfont !== 'undefined') ? data.activeSoundfont : (currentSettings.soundfont || 'bundled');
        if (cur.includes('Built-in') || cur === 'default') cur = 'bundled';
        let curIdx = options.findIndex(opt => opt.toLowerCase() === cur.toLowerCase());
        if (curIdx < 0) curIdx = 0;
        const next = options[(curIdx + 1) % options.length];
        selectMediaFromTv('soundfont', next);
      })
      .catch(() => showToast('Could not fetch soundfont list'));
  }

  function openMediaManager(tab) {
    closeAllModals();
    const modal = document.getElementById('modal-tv-media');
    if (!modal) return;
    modal.style.display = 'flex';
    const deck = document.getElementById('tv-stage-deck');
    if (deck) deck.setAttribute('inert', '');
    const rUrl = document.getElementById('tv-media-remote-url');
    if (rUrl) {
      rUrl.textContent = window.location.origin + '/remote';
    }
    switchMediaTab(tab || currentMediaTab || 'bgv');
  }

  function closeMediaManager() {
    const modal = document.getElementById('modal-tv-media');
    if (modal) modal.style.display = 'none';
    TvNavigator.clearFocus();
    const deck = document.getElementById('tv-stage-deck');
    if (deck) deck.removeAttribute('inert');
  }

  function switchMediaTab(tab) {
    currentMediaTab = tab || 'bgv';
    ['bgv', 'photo', 'soundfont'].forEach(t => {
      const btn = document.getElementById(`tv-mtab-${t === 'soundfont' ? 'soundfont' : t}`);
      if (btn) {
        if (t === currentMediaTab) {
          btn.classList.add('active');
          btn.style.background = '#2563eb';
          btn.style.color = '#fff';
        } else {
          btn.classList.remove('active');
          btn.style.background = 'transparent';
          btn.style.color = '#94a3b8';
        }
      }
    });
    loadMediaManagerList(currentMediaTab);
  }

  function loadMediaManagerList(tab) {
    const container = document.getElementById('tv-media-items-list');
    if (!container) return;
    container.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;">Loading media items...</div>';

    fetch('/api/media/list', { headers: AUTH_HEADERS })
      .then(res => res.json())
      .then(data => {
        cachedMediaData = data;
        updateActiveMediaLabels(data);

        container.innerHTML = '';
        const curTab = tab || currentMediaTab;

        if (curTab === 'bgv') {
          const isAuto = (!data.activeBgv || data.activeBgv === 'AUTO');
          const autoCard = document.createElement('div');
          autoCard.className = 'tv-media-card' + (isAuto ? ' active-media' : '');
          autoCard.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:' + (isAuto ? 'rgba(0,229,255,0.12)' : '#131b2e') + ';border-radius:12px;border:1.5px solid ' + (isAuto ? 'var(--accent-cyan)' : 'rgba(255,255,255,0.08)') + ';';
          autoCard.innerHTML = `
            <div style="display:flex;align-items:center;gap:14px;">
              <span style="font-size:1.8rem;">🔀</span>
              <div>
                <div style="font-weight:700;color:#fff;font-size:1rem;">Auto Shuffle Videos</div>
                <div style="font-size:0.8rem;color:#94a3b8;">Rotates through all background videos on each song</div>
              </div>
            </div>
            <div>
              ${isAuto ? '<span class="tv-media-badge tv-badge-active" style="padding:4px 10px;border-radius:6px;font-size:0.75rem;font-weight:700;background:rgba(0,229,255,0.2);color:var(--accent-cyan);border:1px solid var(--accent-cyan);">ACTIVE SHUFFLE</span>' :
              `<button class="tv-btn-action" style="padding:6px 14px;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;border:none;" onclick="window.SinghubHost.selectMediaFromTv('bgv', 'AUTO')">Activate</button>`}
            </div>
          `;
          container.appendChild(autoCard);

          if (!data.bgvs || data.bgvs.length === 0) {
            const emptyDiv = document.createElement('div');
            emptyDiv.style.cssText = 'color:#64748b;text-align:center;padding:24px;font-size:0.9rem;';
            emptyDiv.textContent = 'No custom videos found. Use the Phone Remote to upload videos (.mp4 / .webm).';
            container.appendChild(emptyDiv);
            return;
          }

          data.bgvs.forEach(item => {
            const isActive = (data.activeBgv === item.name);
            const card = document.createElement('div');
            card.className = 'tv-media-card' + (isActive ? ' active-media' : '');
            card.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:' + (isActive ? 'rgba(0,229,255,0.12)' : '#131b2e') + ';border-radius:12px;border:1.5px solid ' + (isActive ? 'var(--accent-cyan)' : 'rgba(255,255,255,0.08)') + ';';
            card.innerHTML = `
              <div style="display:flex;align-items:center;gap:14px;min-width:0;flex:1;">
                <span style="font-size:1.6rem;flex-shrink:0;">🎬</span>
                <div style="min-width:0;overflow:hidden;">
                  <div style="font-weight:700;color:#fff;font-size:0.95rem;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;">${item.name}</div>
                  <div style="font-size:0.78rem;color:#94a3b8;display:flex;gap:10px;margin-top:2px;">
                    <span>Size: ${item.sizeStr || 'Unknown'}</span>
                    ${item.bundled ? '<span style="color:#a855f7;">Bundled</span>' : '<span style="color:#00f59b;">Custom Video</span>'}
                  </div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                ${isActive ? '<span class="tv-media-badge tv-badge-active" style="padding:4px 10px;border-radius:6px;font-size:0.75rem;font-weight:700;background:rgba(0,229,255,0.2);color:var(--accent-cyan);border:1px solid var(--accent-cyan);">ACTIVE</span>' :
                `<button class="tv-btn-action" style="padding:6px 14px;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;border:none;" onclick="window.SinghubHost.selectMediaFromTv('bgv', '${item.name.replace(/'/g, "\\'")}')">Activate</button>`}
                ${!item.bundled ? `<button class="tv-btn-action" style="padding:6px 10px;border-radius:8px;background:#ef4444;color:#fff;font-size:0.78rem;cursor:pointer;border:none;" onclick="window.SinghubHost.deleteMediaFromTv('bgv', '${item.name.replace(/'/g, "\\'")}')" title="Delete">🗑</button>` : ''}
              </div>
            `;
            container.appendChild(card);
          });

        } else if (curTab === 'photo') {
          const isAuto = (!data.activePhoto || data.activePhoto === 'AUTO');
          const autoCard = document.createElement('div');
          autoCard.className = 'tv-media-card' + (isAuto ? ' active-media' : '');
          autoCard.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:' + (isAuto ? 'rgba(0,229,255,0.12)' : '#131b2e') + ';border-radius:12px;border:1.5px solid ' + (isAuto ? 'var(--accent-cyan)' : 'rgba(255,255,255,0.08)') + ';';
          autoCard.innerHTML = `
            <div style="display:flex;align-items:center;gap:14px;">
              <span style="font-size:1.8rem;">🌄</span>
              <div>
                <div style="font-weight:700;color:#fff;font-size:1rem;">Auto Slideshow Photos</div>
                <div style="font-size:0.8rem;color:#94a3b8;">Rotates photos on each song automatically</div>
              </div>
            </div>
            <div>
              ${isAuto ? '<span class="tv-media-badge tv-badge-active" style="padding:4px 10px;border-radius:6px;font-size:0.75rem;font-weight:700;background:rgba(0,229,255,0.2);color:var(--accent-cyan);border:1px solid var(--accent-cyan);">ACTIVE SLIDESHOW</span>' :
              `<button class="tv-btn-action" style="padding:6px 14px;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;border:none;" onclick="window.SinghubHost.selectMediaFromTv('photo', 'AUTO')">Activate</button>`}
            </div>
          `;
          container.appendChild(autoCard);

          if (!data.photos || data.photos.length === 0) {
            const emptyDiv = document.createElement('div');
            emptyDiv.style.cssText = 'color:#64748b;text-align:center;padding:24px;font-size:0.9rem;';
            emptyDiv.textContent = 'No photos found. Upload photos (.jpg / .png) via Phone Remote or USB.';
            container.appendChild(emptyDiv);
            return;
          }

          data.photos.forEach(item => {
            const isActive = (data.activePhoto === item.name);
            const card = document.createElement('div');
            card.className = 'tv-media-card' + (isActive ? ' active-media' : '');
            card.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:10px 16px;background:' + (isActive ? 'rgba(0,229,255,0.12)' : '#131b2e') + ';border-radius:12px;border:1.5px solid ' + (isActive ? 'var(--accent-cyan)' : 'rgba(255,255,255,0.08)') + ';';
            card.innerHTML = `
              <div style="display:flex;align-items:center;gap:14px;min-width:0;flex:1;">
                <img src="/api/media/photo?name=${encodeURIComponent(item.name)}" style="width:58px;height:42px;object-fit:cover;border-radius:6px;border:1px solid rgba(255,255,255,0.15);background:#070a13;flex-shrink:0;" alt="thumb">
                <div style="min-width:0;overflow:hidden;">
                  <div style="font-weight:700;color:#fff;font-size:0.95rem;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;">${item.name}</div>
                  <div style="font-size:0.78rem;color:#94a3b8;display:flex;gap:10px;margin-top:2px;">
                    <span>Size: ${item.sizeStr || 'Unknown'}</span>
                    ${item.bundled ? '<span style="color:#a855f7;">Bundled</span>' : '<span style="color:#00f59b;">Custom Photo</span>'}
                  </div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                ${isActive ? '<span class="tv-media-badge tv-badge-active" style="padding:4px 10px;border-radius:6px;font-size:0.75rem;font-weight:700;background:rgba(0,229,255,0.2);color:var(--accent-cyan);border:1px solid var(--accent-cyan);">ACTIVE</span>' :
                `<button class="tv-btn-action" style="padding:6px 14px;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;border:none;" onclick="window.SinghubHost.selectMediaFromTv('photo', '${item.name.replace(/'/g, "\\'")}')">Activate</button>`}
                ${!item.bundled ? `<button class="tv-btn-action" style="padding:6px 10px;border-radius:8px;background:#ef4444;color:#fff;font-size:0.78rem;cursor:pointer;border:none;" onclick="window.SinghubHost.deleteMediaFromTv('photo', '${item.name.replace(/'/g, "\\'")}')" title="Delete">🗑</button>` : ''}
              </div>
            `;
            container.appendChild(card);
          });

        } else if (curTab === 'soundfont') {
          if (!data.soundfonts || data.soundfonts.length === 0) {
            const emptyDiv = document.createElement('div');
            emptyDiv.style.cssText = 'color:#64748b;text-align:center;padding:24px;font-size:0.9rem;';
            emptyDiv.textContent = 'No soundfonts detected. Default SAM5504B synth active.';
            container.appendChild(emptyDiv);
            return;
          }

          data.soundfonts.forEach(item => {
            const isBundled = item.bundled || item.path === 'bundled' || (item.name && item.name.includes('Built-in')) || item.name === 'bundled' || item.name === 'default.sf2';
            const curActive = (data.activeSoundfont && data.activeSoundfont !== 'undefined') ? data.activeSoundfont : 'bundled';
            const isActive = (curActive === 'bundled' && isBundled) || (!isBundled && curActive === item.name);
            const targetName = isBundled ? 'bundled' : item.name;
            const card = document.createElement('div');
            card.className = 'tv-media-card' + (isActive ? ' active-media' : '');
            card.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:' + (isActive ? 'rgba(0,229,255,0.12)' : '#131b2e') + ';border-radius:12px;border:1.5px solid ' + (isActive ? 'var(--accent-cyan)' : 'rgba(255,255,255,0.08)') + ';';
            card.innerHTML = `
              <div style="display:flex;align-items:center;gap:14px;min-width:0;flex:1;">
                <span style="font-size:1.6rem;flex-shrink:0;">🎹</span>
                <div style="min-width:0;overflow:hidden;">
                  <div style="font-weight:700;color:#fff;font-size:0.95rem;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;">${isBundled ? 'Dream SAM5504B Studio (Built-in)' : item.name}</div>
                  <div style="font-size:0.78rem;color:#94a3b8;display:flex;gap:10px;margin-top:2px;">
                    <span>Size: ${item.sizeStr || formatBytes(item.size) || '132 MB'}</span>
                    ${isBundled ? '<span style="color:#00f59b;font-weight:600;">Built-in Soundfont</span>' : '<span style="color:#38bdf8;">Custom Soundfont (.sf2)</span>'}
                  </div>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                ${isActive ? '<span class="tv-media-badge tv-badge-active" style="padding:4px 10px;border-radius:6px;font-size:0.75rem;font-weight:700;background:rgba(0,229,255,0.2);color:var(--accent-cyan);border:1px solid var(--accent-cyan);">ACTIVE SYNTH</span>' :
                `<button class="tv-btn-action" style="padding:6px 14px;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;border:none;" onclick="window.SinghubHost.selectMediaFromTv('soundfont', '${targetName.replace(/'/g, "\\'")}')">Activate</button>`}
                ${!isBundled ? `<button class="tv-btn-action" style="padding:6px 10px;border-radius:8px;background:#ef4444;color:#fff;font-size:0.78rem;cursor:pointer;border:none;" onclick="window.SinghubHost.deleteMediaFromTv('soundfont', '${item.name.replace(/'/g, "\\'")}')" title="Delete">🗑</button>` : ''}
              </div>
            `;
            container.appendChild(card);
          });
        }
      })
      .catch(err => {
        container.innerHTML = '<div style="color:#ef4444;text-align:center;padding:20px;">Failed to load media list: ' + err + '</div>';
      });
  }

  function selectMediaFromTv(type, name) {
    if (type === 'soundfont' && (!name || name === 'default' || name === 'undefined' || name.includes('Built-in') || name.includes('SAM5504B') || name === 'bundled')) {
      name = 'bundled';
    }
    // Instantly apply locally so TV Stage visuals & audio synth switch live with 0 delay!
    handleApplyMedia({ mediaType: type, name: name });
    if (window.SinghubNative && window.SinghubNative.selectMediaNative) {
      try { window.SinghubNative.selectMediaNative(type, name); } catch (e) {}
    }
    fetch('/api/media/select', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: type, name: name })
    })
      .then(r => r.json())
      .then(res => {
        loadMediaManagerList(currentMediaTab);
        updateActiveMediaLabels();
      })
      .catch(err => {});
  }

  function deleteMediaFromTv(type, name) {
    if (!confirm('Are you sure you want to delete "' + name + '"?')) return;
    fetch('/api/media/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: type, name: name })
    })
      .then(r => r.json())
      .then(res => {
        showToast('Deleted ' + name);
        loadMediaManagerList(currentMediaTab);
      })
      .catch(err => showToast('Delete failed: ' + err));
  }

  function pickAndAddMediaFromTv() {
    if (window.SinghubNative && window.SinghubNative.pickAndAddMedia) {
      window.SinghubNative.pickAndAddMedia(currentMediaTab);
    } else {
      const input = document.createElement('input');
      input.type = 'file';
      if (currentMediaTab === 'bgv') input.accept = 'video/mp4,video/webm,video/*';
      else if (currentMediaTab === 'photo') input.accept = 'image/jpeg,image/png,image/webp,image/*';
      else if (currentMediaTab === 'soundfont') input.accept = '.sf2,audio/x-soundfont';
      
      input.onchange = (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        if (currentMediaTab === 'soundfont' && file.size > 80 * 1024 * 1024) {
          showToast('SoundFont exceeds 80 MB limit. Please use a soundfont under 80 MB to avoid crashes.');
          return;
        }
        showToast('Uploading ' + file.name + '...');
        const xhr = new XMLHttpRequest();
        const uploadUrl = '/api/media/upload?type=' + encodeURIComponent(currentMediaTab) + '&name=' + encodeURIComponent(file.name);
        xhr.open('POST', uploadUrl, true);
        xhr.setRequestHeader('Content-Type', 'application/octet-stream');
        xhr.onload = () => {
          if (xhr.status === 200) {
            showToast('Uploaded ' + file.name + ' successfully!');
            loadMediaManagerList(currentMediaTab);
          } else {
            showToast('Upload error: HTTP ' + xhr.status);
          }
        };
        xhr.onerror = () => showToast('Upload network error');
        xhr.send(file);
      };
      input.click();
    }
  }

  function handleApplyMedia(cmd) {
    if (!cmd) return;
    const type = cmd.mediaType;
    const name = cmd.name;
    const url = cmd.url;

    if (type === 'bgv') {
      if (name === 'AUTO') {
        switchNextBgv();
      } else {
        playBgVideoUrl(url || ('/video?name=' + encodeURIComponent(name) + '&t=' + Date.now()));
      }
    } else if (type === 'photo') {
      const bgp = document.getElementById('bg-photo');
      const bgv = document.getElementById('bg-video');
      if (bgv) {
        bgv.pause();
        bgv.style.display = 'none';
      }
      if (bgp) {
        bgp.style.display = 'block';
        if (name === 'AUTO') {
          bgp.src = '/api/bgphoto/random?t=' + Date.now();
        } else {
          bgp.src = url || ('/api/media/photo?name=' + encodeURIComponent(name) + '&t=' + Date.now());
        }
      }
    } else if (type === 'soundfont') {
      const isBundled = (!name || name === 'bundled' || name === 'default' || name === 'undefined' || name.includes('Built-in') || name.includes('SAM5504B'));
      const safeName = isBundled ? 'bundled' : name;
      currentSettings.soundfont = safeName;
      const wm = document.getElementById('web-midi-player');
      if (safeName === 'bundled') {
        // Returning to built-in hardware synthesizer: STOP web player and RESUME NATIVE AUDIO!
        if (wm && typeof wm.stop === 'function') {
          try { wm.stop(); } catch (e) {}
        }
        if (isPlaying && currentSong && !currentSong.hasAudio) {
          try {
            if (window.SinghubNative && window.SinghubNative.playSongNative) {
              window.SinghubNative.playSongNative(currentSong.num, keyShift, tempoShift);
            }
          } catch (e) {}
        }
      } else {
        if (wm) {
          wm.setAttribute('sound-font', '/api/soundfont/active?t=' + Date.now());
          if (isPlaying && currentSong && !currentSong.hasAudio && currentSong.midiUrl) {
            startWebMidiFallback(currentSong.midiUrl);
          }
        }
      }
    }
    try {
      localStorage.setItem('singhub_tv_settings', JSON.stringify(currentSettings));
    } catch (e) {}
    updateActiveMediaLabels();
    broadcastState();
    const modal = document.getElementById('modal-tv-media');
    if (modal && modal.style.display === 'flex') {
      loadMediaManagerList(currentMediaTab);
    }
  }

  function handleMediaDeleted(cmd) {
    if (!cmd) return;
    updateActiveMediaLabels();
    const modal = document.getElementById('modal-tv-media');
    if (modal && modal.style.display === 'flex') {
      loadMediaManagerList(currentMediaTab);
    }
  }

  function openSettingsModal() {
    const modal = document.getElementById('modal-tv-settings');
    if (modal) {
      const isVisible = (modal.style.display && modal.style.display !== 'none');
      if (isVisible) {
        closeAllModals();
      } else {
        closeTvDeckDirectly();
        closeAllModals();
        modal.style.display = 'flex';
        document.body.classList.add('settings-open');
        closeTvDeckDirectly();

        TvNavigator.settingsIdx = 0;
        const curVer = (window.SinghubNative && window.SinghubNative.getAppVersionName) ? window.SinghubNative.getAppVersionName() : '2.0.9';
        const tag = document.getElementById('tv-settings-version-tag');
        if (tag) tag.textContent = 'v' + curVer;
        const sSub = document.getElementById('tv-update-status-sub');
        if (sSub && (!currentUpdateInfo || !currentUpdateInfo.isAvailable)) {
          sSub.textContent = 'Current: v' + curVer + ' • singhub.zoryva.me';
        }
        checkForUpdates(false);

        const closeBtn = document.getElementById('tv-settings-close-btn');
        const items = Array.from(modal.querySelectorAll('.tv-setting-item'));
        const target = items[0] || closeBtn;
        if (target) {
          TvNavigator.settingsIdx = (closeBtn && items.length > 0) ? 1 : 0;
          TvNavigator.setFocus(target);
        }
      }
    }
  }

  function broadcastState() {
    updateDeckPitchTempoBadges();
    const curLine = (songLines && songLines[currentLineIdx]) ? songLines[currentLineIdx] : null;
    const nextLine = (songLines && songLines[currentLineIdx + 1]) ? songLines[currentLineIdx + 1] : null;
    const isIntro = (intro5sTimer !== null) || (introCard && introCard.style.display !== 'none');
    const isInterlude = (interludeBanner && interludeBanner.style.display !== 'none');

    const stateObj = {
      num: currentSong ? currentSong.num : 0,
      title: currentSong ? currentSong.title : '',
      artist: currentSong ? currentSong.artist : '',
      isPlaying: isPlaying,
      currentTime: getAudioTime(),
      duration: currentSong ? currentSong.duration : 0,
      keyShift: keyShift,
      tempoShift: tempoShift,
      volume: masterVolume,
      melodyLevel: melodyLevel,
      mpxMode: mpxMode,
      projMode: projMode,
      playMode: playMode,
      curLineText: curLine ? curLine.text : '',
      nextLineText: nextLine ? nextLine.text : '',
      curLine: curLine,
      nextLine: nextLine,
      currentLineIdx: currentLineIdx,
      countdown: lastCountdownNumber,
      isIntro: isIntro,
      isInterlude: isInterlude,
      queue: songQueue,
      settings: currentSettings,
      remotesConnected: window._remotesCount || 0
    };

    if (window.SinghubNative && window.SinghubNative.updateTvStateNative) {
      window.SinghubNative.updateTvStateNative(JSON.stringify(stateObj));
      return;
    }

    fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(stateObj)
    }).catch(e => {});
  }

  const recentCmdIds = new Set();
  let lastRemoteCmdSig = '';
  let lastRemoteCmdTime = 0;

  function executeCommand(cmd) {
    if (!cmd) return;
    if (typeof cmd === 'string') {
      try { cmd = JSON.parse(cmd); } catch (e) { return; }
    }
    const act = cmd.action;
    if (!act) return;

    if (cmd.cmd_id) {
      if (recentCmdIds.has(cmd.cmd_id)) return;
      recentCmdIds.add(cmd.cmd_id);
      setTimeout(() => recentCmdIds.delete(cmd.cmd_id), 10000);
    } else {
      const sig = act + ':' + (cmd.digit !== undefined ? cmd.digit : '') + ':' + (cmd.num || '') + ':' + (cmd.buffer !== undefined ? cmd.buffer : '') + ':' + (cmd.index !== undefined ? cmd.index : '');
      const now = performance.now();
      if (sig === lastRemoteCmdSig && (now - lastRemoteCmdTime) < 600) {
        return; // Deduplicate duplicate dispatch within 600ms
      }
      lastRemoteCmdSig = sig;
      lastRemoteCmdTime = now;
    }

    if (act === 'load_song' && (cmd.song || cmd.num)) {
      dialCancel();
      loadSong(cmd.song ? cmd.song.num : cmd.num);
    } else if (act === 'play_now' && cmd.num) {
      dialCancel();
      loadSong(cmd.num);
    } else if (act === 'queue_added' || act === 'reserve') {
      dialCancel();
      if (cmd.num) {
        fetch(`/api/song/${cmd.num}`)
          .then(res => res.ok ? res.json() : null)
          .then(song => {
            if (song) {
              songQueue.push(song);
              updatePlayingHeader();
              renderTvDeckQueue();
              broadcastState();
              if (!isPlaying && !currentSong) {
                nextSong();
              }
            }
          })
          .catch(() => {});
      } else if (!isPlaying && !currentSong && songQueue.length > 0) {
        nextSong();
      }
    } else if (act === 'first_reserve') {
      dialCancel();
      if (cmd.num) {
        fetch(`/api/song/${cmd.num}`)
          .then(res => res.ok ? res.json() : null)
          .then(song => {
            if (song) {
              songQueue.unshift(song);
              updatePlayingHeader();
              renderTvDeckQueue();
              broadcastState();
              if (!isPlaying && !currentSong) {
                nextSong();
              }
            }
          })
          .catch(() => {});
      }
    } else if (act === 'remove_queue') {
      if (cmd.index !== undefined && cmd.index >= 0 && cmd.index < songQueue.length) {
        songQueue.splice(cmd.index, 1);
        updatePlayingHeader();
        renderTvDeckQueue();
        broadcastState();
      }
    } else if (act === 'clear_queue') {
      songQueue = [];
      updatePlayingHeader();
      renderTvDeckQueue();
      broadcastState();
    } else if (act === 'play_pause') {
      togglePlayPause();
    } else if (act === 'next') {
      nextSong();
    } else if (act === 'replay') {
      replaySong();
    } else if (act === 'stop') {
      stopSong();
    } else if (act === 'key+' || act === 'key_plus') {
      shiftKey(1);
    } else if (act === 'key-' || act === 'key_minus') {
      shiftKey(-1);
    } else if (act === 'set_key' && cmd.shift !== undefined) {
      keyShift = Math.max(-6, Math.min(6, parseInt(cmd.shift, 10) || 0));
      if (window.SinghubNative && window.SinghubNative.setKeyShiftNative) {
        window.SinghubNative.setKeyShiftNative(keyShift);
      }
      updateDeckPitchTempoBadges();
      broadcastState();
    } else if (act === 'tempo+' || act === 'tempo_plus') {
      shiftTempo(1);
    } else if (act === 'tempo-' || act === 'tempo_minus') {
      shiftTempo(-1);
    } else if (act === 'set_tempo' && cmd.shift !== undefined) {
      tempoShift = Math.max(-10, Math.min(10, parseInt(cmd.shift, 10) || 0));
      if (window.SinghubNative && window.SinghubNative.setTempoShiftNative) {
        window.SinghubNative.setTempoShiftNative(tempoShift);
      }
      updateDeckPitchTempoBadges();
      broadcastState();
    } else if (act === 'vol+' || act === 'vol_plus' || act === 'volume+') {
      shiftVolume(5);
    } else if (act === 'vol-' || act === 'vol_minus' || act === 'volume-') {
      shiftVolume(-5);
    } else if (act === 'set_volume' && cmd.volume !== undefined) {
      shiftVolume(parseInt(cmd.volume, 10) - masterVolume);
    } else if (act === 'switch_bgv') {
      switchNextBgv();
    } else if (act === 'toggle_melody') {
      toggleMelody();
    } else if (act === 'set_melody' && (cmd.level || cmd.melodyLevel)) {
      applySettings({ melodyLevel: cmd.level || cmd.melodyLevel });
    } else if (act === 'toggle_mpx') {
      toggleMpx();
    } else if (act === 'set_mpx' && (cmd.mode || cmd.mpxMode)) {
      applySettings({ mpxMode: cmd.mode || cmd.mpxMode });
    } else if (act === 'toggle_proj') {
      toggleProj();
    } else if (act === 'set_proj' && (cmd.mode || cmd.projMode)) {
      applySettings({ projMode: cmd.mode || cmd.projMode });
    } else if (act === 'cycle_mode') {
      cycleMode();
    } else if (act === 'set_mode' && (cmd.mode || cmd.playMode)) {
      applySettings({ playMode: cmd.mode || cmd.playMode });
    } else if (act === 'apply_settings') {
      applySettings(cmd.settings || cmd);
    } else if (act === 'apply_media') {
      handleApplyMedia(cmd);
    } else if (act === 'open_settings') {
      openSettingsModal();
    } else if (act === 'check_update' || act === 'check_updates') {
      openSettingsModal();
      checkForUpdates(true);
    } else if (act === 'rescan_storage' || act === 'rescan') {
      rescanContent();
    } else if (act === 'dial_digit') {
      if (cmd.buffer !== undefined && typeof cmd.buffer === 'string') {
        dialBuffer = cmd.buffer;
        updateTvDialFromBuffer(dialBuffer);
        playNumberVoice(cmd.digit);
        if (!isPlaying && dialBuffer.length >= 5) {
          if (dialAutoPlayTimer) clearTimeout(dialAutoPlayTimer);
          dialAutoPlayTimer = setTimeout(() => {
            dialCommit();
          }, 4000);
        } else if (dialAutoPlayTimer) {
          clearTimeout(dialAutoPlayTimer);
          dialAutoPlayTimer = null;
        }
      } else {
        onDigitPress(cmd.digit);
      }
    } else if (act === 'dial_set') {
      updateTvDialFromBuffer(cmd.buffer);
    } else if (act === 'dial_backspace') {
      dialBuffer = cmd.buffer !== undefined ? cmd.buffer : dialBuffer.slice(0, -1);
      updateTvDialFromBuffer(dialBuffer);
    } else if (act === 'dial_clear') {
      dialCancel();
    } else if (act === 'dial_enter') {
      dialCommit(true);
    }
  }

  function pollCommands() {
    if (window.SinghubNative) return; // Android Host uses instant direct bridge; never poll HTTP queue
    fetch('/api/command/poll', { headers: AUTH_HEADERS })
      .then(res => res.json())
      .then(data => {
        if (data.commands && data.commands.length > 0) {
          data.commands.forEach(cmd => executeCommand(cmd));
        }
      })
      .catch(e => {})
      .finally(() => {
        if (!window.SinghubNative) setTimeout(pollCommands, 400);
      });
  }

  let lastQueueJson = '';

  function syncQueueWithServer() {
    fetch('/api/state')
      .then(res => res.json())
      .then(data => {
        if (data.queue) {
          const qJson = JSON.stringify(data.queue);
          if (qJson !== lastQueueJson) {
            lastQueueJson = qJson;
            songQueue = data.queue;
            updatePlayingHeader();
            renderTvDeckQueue();
          }
        }
        if (data.melodyLevel) melodyLevel = data.melodyLevel;
        if (data.mpxMode) mpxMode = data.mpxMode;
        if (data.projMode) projMode = data.projMode;
        if (data.playMode) playMode = data.playMode;
      })
      .catch(e => {})
      .finally(() => setTimeout(syncQueueWithServer, 800));
  }

  // --- 11. TV Remote Navigation & Keypad Controller System ---
  const TvNavigator = {
    currentFocus: null,
    padRow: 1, // 0: tabs, 1: 1-3, 2: 4-6, 3: 7-9, 4: clr-0-back, 5: play-res-1st, 6: transport, 7: pitch/tempo, 8: subcontrols
    padCol: 1, // 0..3
    settingsIdx: 0,
    searchSongIdx: -1,
    searchCol: 0, // 0: play, 1: res
    queueIdx: -1, // -1: tab/clear, 0..N: queue item
    mediaIdx: 0,
    lastSelectTime: 0,

    padGrid: [
      ['tv-tab-btn-pad', 'tv-tab-btn-search', 'tv-tab-btn-queue'],
      ['tv-btn-digit-1', 'tv-btn-digit-2', 'tv-btn-digit-3'],
      ['tv-btn-digit-4', 'tv-btn-digit-5', 'tv-btn-digit-6'],
      ['tv-btn-digit-7', 'tv-btn-digit-8', 'tv-btn-digit-9'],
      ['tv-btn-digit-clr', 'tv-btn-digit-0', 'tv-btn-digit-back'],
      ['tv-btn-act-play', 'tv-btn-act-res', 'tv-btn-act-first-res'],
      ['tv-tp-replay', 'tv-tp-playpause', 'tv-tp-next', 'tv-tp-stop'],
      ['tv-sub-key-down', 'tv-sub-key-up', 'tv-sub-tempo-down', 'tv-sub-tempo-up'],
      ['tv-fx-melody', 'tv-fx-mpx', 'tv-fx-bgv', 'tv-fx-settings'],
      ['tv-fx-check-update']
    ],

    getContext() {
      const updateModal = document.getElementById('modal-tv-update');
      if (updateModal && (updateModal.style.display === 'flex' || updateModal.style.display === 'block')) return 'update';
      const settingsModal = document.getElementById('modal-tv-settings');
      if (settingsModal && (settingsModal.style.display === 'flex' || settingsModal.style.display === 'block')) return 'settings';
      const qrModal = document.getElementById('modal-qr');
      if (qrModal && (qrModal.style.display === 'flex' || qrModal.style.display === 'block')) return 'qr';
      const scoreModal = document.getElementById('modal-score');
      if (scoreModal && (scoreModal.style.display === 'flex' || scoreModal.style.display === 'block')) return 'score';
      const mediaModal = document.getElementById('modal-tv-media');
      if (mediaModal && (mediaModal.style.display === 'flex' || mediaModal.style.display === 'block')) return 'media';
      if (isTvDeckOpen) return 'deck';
      return 'stage';
    },

    setFocus(el) {
      if (!el) return;
      if (this.currentFocus && this.currentFocus !== el) {
        this.currentFocus.classList.remove('tv-focused');
      }
      this.currentFocus = el;
      el.classList.add('tv-focused');
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        if (typeof el.focus === 'function') el.focus();
      } else {
        if (document.activeElement && document.activeElement !== document.body && typeof document.activeElement.blur === 'function') {
          try { document.activeElement.blur(); } catch (e) {}
        }
      }
      if (typeof el.scrollIntoView === 'function') {
        el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
      }
    },

    clearFocus() {
      if (this.currentFocus) {
        this.currentFocus.classList.remove('tv-focused');
        this.currentFocus = null;
      }
      if (document.activeElement && typeof document.activeElement.blur === 'function') {
        try { document.activeElement.blur(); } catch (e) {}
      }
    },

    navigate(dir) {
      if (dir === 'select') {
        const now = performance.now();
        if (now - this.lastSelectTime < 250) {
          return;
        }
        this.lastSelectTime = now;
      }

      const ctx = this.getContext();

      // 0. APP UPDATE MODAL CONTEXT
      if (ctx === 'update') {
        const modal = document.getElementById('modal-tv-update');
        if (!modal) return;
        const visibleActions = Array.from(modal.querySelectorAll('.tv-update-actions')).filter(a => a.style.display !== 'none');
        const activeContainer = visibleActions[0] || modal;
        const btns = Array.from(activeContainer.querySelectorAll('.tv-update-act-btn'));
        if (!btns.length) return;
        if (this.updateIdx === undefined || this.updateIdx < 0 || this.updateIdx >= btns.length) {
          this.updateIdx = 0;
        }
        if (dir === 'left' || dir === 'up') {
          this.updateIdx = (this.updateIdx - 1 + btns.length) % btns.length;
          this.setFocus(btns[this.updateIdx]);
        } else if (dir === 'right' || dir === 'down') {
          this.updateIdx = (this.updateIdx + 1) % btns.length;
          this.setFocus(btns[this.updateIdx]);
        } else if (dir === 'select') {
          if (btns[this.updateIdx]) btns[this.updateIdx].click();
        }
        return;
      }

      // 1. SETTINGS DRAWER CONTEXT
      if (ctx === 'settings') {
        const modal = document.getElementById('modal-tv-settings');
        if (!modal) return;
        const closeBtn = document.getElementById('tv-settings-close-btn');
        const items = Array.from(modal.querySelectorAll('.tv-setting-item'));
        const navList = closeBtn ? [closeBtn, ...items] : items;
        if (!navList.length) return;

        if (dir === 'up') {
          this.settingsIdx = (this.settingsIdx - 1 + navList.length) % navList.length;
          this.setFocus(navList[this.settingsIdx]);
        } else if (dir === 'down') {
          this.settingsIdx = (this.settingsIdx + 1) % navList.length;
          this.setFocus(navList[this.settingsIdx]);
        } else if (dir === 'select') {
          if (navList[this.settingsIdx]) navList[this.settingsIdx].click();
        } else if (dir === 'left' || dir === 'right') {
          // If on a setting item (not the close button), left/right cycles setting
          if (this.settingsIdx > 0 && navList[this.settingsIdx]) {
            navList[this.settingsIdx].click();
          }
        }
        return;
      }

      // 2. MODAL QR / SCORE CONTEXT
      if (ctx === 'qr' || ctx === 'score') {
        if (dir === 'select') closeAllModals();
        return;
      }

      // 2b. MEDIA STUDIO MODAL CONTEXT
      if (ctx === 'media') {
        const modal = document.getElementById('modal-tv-media');
        if (!modal) return;
        const clickables = Array.from(modal.querySelectorAll('button, .tv-media-tab-btn, .tv-media-card button, .tv-media-card'));
        if (!clickables.length) return;
        if (dir === 'up' || dir === 'left') {
          this.mediaIdx = ((this.mediaIdx || 0) - 1 + clickables.length) % clickables.length;
          this.setFocus(clickables[this.mediaIdx]);
        } else if (dir === 'down' || dir === 'right') {
          this.mediaIdx = ((this.mediaIdx || 0) + 1) % clickables.length;
          this.setFocus(clickables[this.mediaIdx]);
        } else if (dir === 'select') {
          if (clickables[this.mediaIdx]) clickables[this.mediaIdx].click();
        }
        return;
      }

      // 3. MAIN STAGE CONTEXT (Deck closed)
      if (ctx === 'stage' || !isTvDeckOpen) {
        if (dir === 'down' || dir === 'up' || dir === 'left' || dir === 'right') {
          toggleTvDeck(true);
        } else if (dir === 'select') {
          if (dialBuffer) {
            dialCommit(true);
          } else {
            toggleTvDeck(true);
          }
        }
        return;
      }

      // 4. TV DECK CONTEXT (Deck is open)
      if (ctx === 'deck' && isTvDeckOpen) {
        const activeTabBtn = document.querySelector('.tv-deck-tab.active');
        const activeTabId = activeTabBtn ? activeTabBtn.id : 'tv-tab-btn-pad';

        // 4A: KEYPAD TAB
        if (activeTabId === 'tv-tab-btn-pad') {
          if (dir === 'up') {
            this.padRow = Math.max(0, this.padRow - 1);
          } else if (dir === 'down') {
            this.padRow = Math.min(this.padGrid.length - 1, this.padRow + 1);
          } else if (dir === 'left') {
            if (this.padRow === 0) {
              this.padCol = (this.padCol - 1 + 3) % 3;
            } else {
              this.padCol = Math.max(0, this.padCol - 1);
            }
          } else if (dir === 'right') {
            const rowMax = this.padGrid[this.padRow].length - 1;
            if (this.padRow === 0) {
              this.padCol = (this.padCol + 1) % 3;
            } else {
              this.padCol = Math.min(rowMax, this.padCol + 1);
            }
          } else if (dir === 'select') {
            if (this.currentFocus) {
              this.currentFocus.click();
              return;
            }
          }

          const rowItems = this.padGrid[this.padRow];
          const colIndex = Math.min(this.padCol, rowItems.length - 1);
          const elId = rowItems[colIndex];
          const el = document.getElementById(elId);
          if (el) this.setFocus(el);
          return;
        }

        // 4B: SONG SEARCH TAB
        if (activeTabId === 'tv-tab-btn-search') {
          const searchInput = document.getElementById('tv-deck-search-input');
          const songRows = Array.from(document.querySelectorAll('.tv-deck-item'));
          const searchTabBtn = document.getElementById('tv-tab-btn-search');

          if (dir === 'up') {
            if (this.searchSongIdx > 0) {
              this.searchSongIdx--;
              this.focusSongBtn(songRows[this.searchSongIdx]);
            } else if (this.searchSongIdx === 0) {
              this.searchSongIdx = -1;
              this.setFocus(searchInput);
            } else {
              this.setFocus(searchTabBtn);
            }
          } else if (dir === 'down') {
            if (this.currentFocus === searchTabBtn) {
              this.setFocus(searchInput);
            } else if (this.searchSongIdx === -1 && songRows.length > 0) {
              this.searchSongIdx = 0;
              this.focusSongBtn(songRows[0]);
            } else if (this.searchSongIdx < songRows.length - 1) {
              this.searchSongIdx++;
              this.focusSongBtn(songRows[this.searchSongIdx]);
            }
          } else if (dir === 'left') {
            if (this.currentFocus === searchTabBtn || this.currentFocus === searchInput) {
              switchTvDeckTab('pad');
              this.padRow = 0;
              this.padCol = 0;
              this.setFocus(document.getElementById('tv-tab-btn-pad'));
            } else {
              this.searchCol = 0;
              if (this.searchSongIdx >= 0 && songRows[this.searchSongIdx]) {
                this.focusSongBtn(songRows[this.searchSongIdx]);
              }
            }
          } else if (dir === 'right') {
            if (this.currentFocus === searchTabBtn || this.currentFocus === searchInput) {
              switchTvDeckTab('queue');
              this.setFocus(document.getElementById('tv-tab-btn-queue'));
            } else {
              this.searchCol = 1;
              if (this.searchSongIdx >= 0 && songRows[this.searchSongIdx]) {
                this.focusSongBtn(songRows[this.searchSongIdx]);
              }
            }
          } else if (dir === 'select') {
            if (this.currentFocus) this.currentFocus.click();
          }
          return;
        }

        // 4C: QUEUE TAB
        if (activeTabId === 'tv-tab-btn-queue') {
          const qTabBtn = document.getElementById('tv-tab-btn-queue');
          const clearBtn = document.querySelector('.tv-q-clear-btn');
          const qButtons = Array.from(document.querySelectorAll('.tv-deck-queue-item .tv-deck-mini-btn'));

          if (dir === 'select') {
            if (this.currentFocus) this.currentFocus.click();
            return;
          }

          if (dir === 'left') {
            if (this.currentFocus === qTabBtn) {
              switchTvDeckTab('search');
              this.setFocus(document.getElementById('tv-tab-btn-search'));
            } else {
              this.setFocus(qTabBtn);
            }
            return;
          }

          if (dir === 'right') {
            if (this.currentFocus === qTabBtn) {
              switchTvDeckTab('pad');
              this.padRow = 0;
              this.padCol = 0;
              this.setFocus(document.getElementById('tv-tab-btn-pad'));
            } else if (this.currentFocus === clearBtn && qButtons.length) {
              this.queueIdx = 0;
              this.setFocus(qButtons[0]);
            }
            return;
          }

          if (dir === 'down') {
            if (this.currentFocus === qTabBtn) {
              if (clearBtn) {
                this.setFocus(clearBtn);
              } else if (qButtons.length) {
                this.queueIdx = 0;
                this.setFocus(qButtons[0]);
              }
            } else if (this.currentFocus === clearBtn) {
              if (qButtons.length) {
                this.queueIdx = 0;
                this.setFocus(qButtons[0]);
              }
            } else if (qButtons.length) {
              if (this.queueIdx < qButtons.length - 1) {
                this.queueIdx++;
                this.setFocus(qButtons[this.queueIdx]);
              }
            }
            return;
          }

          if (dir === 'up') {
            if (this.currentFocus === clearBtn) {
              this.setFocus(qTabBtn);
            } else if (qButtons.length && this.queueIdx >= 0) {
              if (this.queueIdx > 0) {
                this.queueIdx--;
                this.setFocus(qButtons[this.queueIdx]);
              } else {
                this.queueIdx = -1;
                if (clearBtn) this.setFocus(clearBtn);
                else this.setFocus(qTabBtn);
              }
            } else {
              this.setFocus(qTabBtn);
            }
            return;
          }
        }
      }

      // 5. STAGE CONTEXT (Main karaoke stage, deck closed, no modal open)
      if (ctx === 'stage') {
        const topBadge = document.getElementById('top-update-badge');
        const topRemote = document.getElementById('top-remote-line');
        const topItems = [];
        if (topBadge && topBadge.style.display !== 'none') topItems.push(topBadge);
        if (topRemote) topItems.push(topRemote);

        if (dir === 'up') {
          const target = (topBadge && topBadge.style.display !== 'none') ? topBadge : topRemote;
          if (target) this.setFocus(target);
          return;
        } else if (dir === 'down') {
          if (this.currentFocus && topItems.includes(this.currentFocus)) {
            this.clearFocus();
          } else {
            toggleTvDeck(true);
          }
          return;
        } else if (dir === 'left') {
          if (this.currentFocus && topItems.includes(this.currentFocus)) {
            const idx = topItems.indexOf(this.currentFocus);
            const prev = topItems[(idx - 1 + topItems.length) % topItems.length];
            this.setFocus(prev);
            return;
          }
        } else if (dir === 'right') {
          if (this.currentFocus && topItems.includes(this.currentFocus)) {
            const idx = topItems.indexOf(this.currentFocus);
            const next = topItems[(idx + 1) % topItems.length];
            this.setFocus(next);
            return;
          }
        } else if (dir === 'select') {
          if (this.currentFocus && topItems.includes(this.currentFocus)) {
            this.currentFocus.click();
            return;
          }
          if (dialBuffer) {
            dialCommit(true);
          } else {
            toggleTvDeck(true);
          }
          return;
        }
      }
    },

    focusSongBtn(songRow) {
      if (!songRow) return;
      const btns = songRow.querySelectorAll('.tv-deck-mini-btn');
      const target = btns[this.searchCol] || btns[0];
      if (target) this.setFocus(target);
    }
  };

  function handleTvColor(color) {
    if (color === 'red') {
      if (dialBuffer) deckPressClear();
      else if (isPlaying) stopSong();
      else showToast('Stopped');
    } else if (color === 'green') {
      if (dialBuffer) deckActionReserve(false);
      else {
        toggleTvDeck(true);
        switchTvDeckTab('search');
      }
    } else if (color === 'yellow') {
      replaySong();
    } else if (color === 'blue') {
      toggleTvDeck();
    }
  }

  // --- Physical Keyboard & TV Remote Listener ---
  window.addEventListener('keydown', (e) => {
    // If inside an input element (like search), only allow typing or Escape
    const isInput = e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA');
    if (isInput && e.key !== 'Escape') {
      return;
    }

    // CRITICAL FIX: When running inside the Android Native TV App, MainActivity.dispatchKeyEvent
    // intercepts and directly dispatches all remote keys (0-9, D-Pad, Enter, Backspace, Escape).
    // Allowing DOM keydown to also process these keys causes the infamous double-dispatch bug
    // (e.g. clicking '3' on the physical remote calls onDigitPress TWICE -> shows '33').
    if (window.SinghubNative) {
      const isHandledByNative = (e.key >= '0' && e.key <= '9') ||
        e.key === 'Enter' || e.key === 'Backspace' || e.key === 'Escape' ||
        e.key.startsWith('Arrow') || e.key === ' ' || e.repeat;
      if (isHandledByNative) {
        e.preventDefault();
        return;
      }
    }

    if (e.repeat) {
      e.preventDefault();
      return;
    }

    // Digits 0 to 9 (only for standalone web browser / PC)
    if (e.key >= '0' && e.key <= '9') {
      e.preventDefault();
      onDigitPress(e.key);
      return;
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      TvNavigator.navigate('select');
      return;
    }

    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      if (isDownloadActive) {
        showToast('⚠️ DONT CLOSE: Downloading resources in progress');
        return;
      }
      if (TvNavigator.getContext() === 'settings' || TvNavigator.getContext() === 'qr' || TvNavigator.getContext() === 'score') {
        closeAllModals();
      } else if (isTvDeckOpen) {
        toggleTvDeck(false);
      } else if (dialBuffer) {
        dialCancel();
      }
      return;
    }

    if (e.key === 'Backspace') {
      e.preventDefault();
      deckPressBackspace();
      return;
    }

    if (e.key === ' ') {
      e.preventDefault();
      togglePlayPause();
      return;
    }

    const lower = e.key.toLowerCase();
    if (lower === 'n') { e.preventDefault(); nextSong(); }
    else if (lower === 'r') { e.preventDefault(); replaySong(); }
    else if (lower === 's') { e.preventDefault(); stopSong(); }
    else if (lower === 'q') { e.preventDefault(); openQrModal(); }
    else if (e.key === 'F2' || lower === 'o') { e.preventDefault(); openSettingsModal(); }
    else if (lower === 'm') { e.preventDefault(); toggleTvDeck(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); e.stopPropagation(); TvNavigator.navigate('up'); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); e.stopPropagation(); TvNavigator.navigate('down'); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); e.stopPropagation(); TvNavigator.navigate('right'); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); e.stopPropagation(); TvNavigator.navigate('left'); }
  });

  // --- 12. TV Stage On-Screen Keypad Deck Functions ---
  let isTvDeckOpen = false;
  const DECK_SCALE_MIN = 0.75;
  const DECK_BASE_W = 240;
  const DECK_BASE_H = 420;
  let deckScale = 1;

  function getTvDeckMaxScale() {
    const topbar = document.querySelector('.osd-topbar');
    const wrapper = document.getElementById('tv-deck-wrapper');
    const topLimit = topbar ? (topbar.getBoundingClientRect().bottom + 12) : 72;
    const wrapRect = wrapper ? wrapper.getBoundingClientRect() : null;
    const bottomEdge = wrapRect ? (wrapRect.bottom - 44) : (window.innerHeight - 60);
    const rightEdge = wrapRect ? wrapRect.right : (window.innerWidth - 16);
    const availH = Math.max(160, bottomEdge - topLimit);
    const availW = Math.max(160, rightEdge - 16);
    const maxByH = availH / DECK_BASE_H;
    const maxByW = availW / DECK_BASE_W;
    return Math.max(DECK_SCALE_MIN, Math.min(2.0, maxByH, maxByW));
  }

  function applyTvDeckScale(scale, save) {
    const maxScale = getTvDeckMaxScale();
    const next = Math.round(Math.max(DECK_SCALE_MIN, Math.min(maxScale, Number(scale) || 1)) * 100) / 100;
    deckScale = next;
    const deck = document.getElementById('tv-stage-deck');
    if (deck) deck.style.setProperty('--deck-scale', String(deckScale));
    if (save !== false) {
      try { localStorage.setItem('tv_deck_scale', String(deckScale)); } catch (e) {}
    }
  }

  function initTvDeckResizer() {
    try {
      const saved = parseFloat(localStorage.getItem('tv_deck_scale'));
      if (!isNaN(saved) && saved > 0) applyTvDeckScale(saved, false);
      else applyTvDeckScale(1, false);
    } catch (e) {
      applyTvDeckScale(1, false);
    }

    const deck = document.getElementById('tv-stage-deck');
    const handle = document.getElementById('tv-deck-resize-handle');
    if (!deck || !handle) return;

    let resizing = false;
    let startX = 0;
    let startY = 0;
    let startScale = 1;

    const onMove = (clientX, clientY) => {
      if (!resizing) return;
      // Drag left / up from the top-left corner = grow (stays bottom-right anchored)
      const delta = ((startX - clientX) + (startY - clientY)) / 220;
      applyTvDeckScale(startScale + delta, false);
    };

    const endResize = () => {
      if (!resizing) return;
      resizing = false;
      deck.classList.remove('tv-deck-resizing');
      applyTvDeckScale(deckScale, true);
    };

    handle.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      resizing = true;
      startX = e.clientX;
      startY = e.clientY;
      startScale = deckScale;
      deck.classList.add('tv-deck-resizing');
      try { handle.setPointerCapture(e.pointerId); } catch (err) {}
    });

    handle.addEventListener('pointermove', (e) => {
      if (!resizing) return;
      e.preventDefault();
      onMove(e.clientX, e.clientY);
    });

    handle.addEventListener('pointerup', endResize);
    handle.addEventListener('pointercancel', endResize);
    handle.addEventListener('lostpointercapture', endResize);

    window.addEventListener('resize', () => applyTvDeckScale(deckScale, true));
  }

  function toggleTvDeck(forceState) {
    if (forceState === false) {
      closeTvDeckDirectly();
      return;
    }

    if (forceState === undefined && (TvNavigator.getContext() === 'settings' || TvNavigator.getContext() === 'qr' || TvNavigator.getContext() === 'score' || TvNavigator.getContext() === 'media')) {
      closeAllModals();
      return;
    }

    isTvDeckOpen = (forceState !== undefined) ? forceState : !isTvDeckOpen;
    const deck = document.getElementById('tv-stage-deck');
    const arrow = document.getElementById('tv-deck-arrow');
    const toggleBtn = document.getElementById('tv-deck-toggle-btn');
    const deckWrapper = document.getElementById('tv-deck-wrapper');

    if (deck) {
      if (isTvDeckOpen) {
        if (deckWrapper) {
          deckWrapper.classList.remove('deck-force-hidden');
          deckWrapper.style.display = '';
          deckWrapper.style.pointerEvents = '';
          deckWrapper.style.visibility = '';
        }
        deck.classList.remove('tv-deck-hidden');
        deck.removeAttribute('inert');
        setTimeout(() => {
          const activeTabBtn = document.querySelector('.tv-deck-tab.active');
          const activeTabId = activeTabBtn ? activeTabBtn.id : 'tv-tab-btn-pad';
          if (activeTabId === 'tv-tab-btn-search') {
            TvNavigator.searchSongIdx = -1;
            const searchInput = document.getElementById('tv-deck-search-input');
            TvNavigator.setFocus(searchInput || document.getElementById('tv-tab-btn-search'));
          } else if (activeTabId === 'tv-tab-btn-queue') {
            TvNavigator.queueIdx = -1;
            TvNavigator.setFocus(document.getElementById('tv-tab-btn-queue'));
          } else {
            TvNavigator.padRow = 1;
            TvNavigator.padCol = 1;
            const el = document.getElementById('tv-btn-digit-2');
            if (el) TvNavigator.setFocus(el);
          }
        }, 50);
      } else {
        closeTvDeckDirectly();
        TvNavigator.clearFocus();
      }
    }
    if (arrow) {
      arrow.textContent = isTvDeckOpen ? '▼' : '▲';
      if (isTvDeckOpen) {
        arrow.classList.remove('deck-arrow-anim');
      } else {
        arrow.classList.add('deck-arrow-anim');
      }
    }
    if (toggleBtn) {
      toggleBtn.title = isTvDeckOpen ? 'Close Keypad' : 'Open Keypad';
    }
  }

  function switchTvDeckTab(tabId) {
    document.querySelectorAll('.tv-deck-panel').forEach(p => p.style.display = 'none');
    document.querySelectorAll('.tv-deck-tab').forEach(b => b.classList.remove('active'));

    const panel = document.getElementById('tv-deck-panel-' + tabId);
    const btn = document.getElementById('tv-tab-btn-' + tabId);
    if (panel) panel.style.display = 'flex';
    if (btn) btn.classList.add('active');

    if (tabId === 'pad') {
      TvNavigator.padRow = 0;
      TvNavigator.padCol = 0;
      if (btn) TvNavigator.setFocus(btn);
    } else if (tabId === 'search') {
      TvNavigator.searchSongIdx = -1;
      TvNavigator.searchCol = 0;
      const searchInput = document.getElementById('tv-deck-search-input');
      TvNavigator.setFocus(searchInput || btn);
      const resultsContainer = document.getElementById('tv-deck-search-results');
      if (resultsContainer && (!resultsContainer.hasChildNodes() || currentDeckSearchOffset === 0)) {
        const q = searchInput ? searchInput.value : '';
        executeDeckSearch(q, false);
      }
    } else if (tabId === 'queue') {
      TvNavigator.queueIdx = -1;
      if (btn) TvNavigator.setFocus(btn);
      renderTvDeckQueue();
      syncQueueWithServer();
    }
  }

  function deckPressClear() {
    lastDigitPressTime = 0;
    lastDigitPressed = null;
    dialCancel();
    const digits = document.getElementById('tv-deck-digits');
    const title = document.getElementById('tv-deck-title');
    if (digits) digits.textContent = '000000';
    if (title) title.textContent = 'Ready - Dial Code or Pick Song';
  }

  let lastBackspaceTime = 0;
  function deckPressBackspace() {
    const now = performance.now();
    if (now - lastBackspaceTime < 150) return;
    lastBackspaceTime = now;
    lastDigitPressTime = 0;
    lastDigitPressed = null;
    dialBuffer = dialBuffer.slice(0, -1);
    updateTvDialFromBuffer(dialBuffer);
  }

  function deckActionPlay() {
    if (!dialBuffer) return;
    const num = parseInt(dialBuffer, 10);
    dialCancel();
    loadSong(num);
  }

  function deckActionReserve(isFirst) {
    if (!dialBuffer) return;
    const num = parseInt(dialBuffer, 10);
    dialCancel();
    fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: isFirst ? 'first_reserve' : 'reserve', num: num })
    })
    .then(res => res.json())
    .then(() => {
      syncQueueWithServer();
    })
    .catch(() => {});
  }

  // --- TV Deck Infinite Scroll Songbook ---
  let deckSearchDebounce = null;
  let currentDeckSearchQuery = '';
  let currentDeckSearchOffset = 0;
  const DECK_PAGE_SIZE = 25;
  let isDeckSearching = false;
  let hasMoreDeckResults = true;

  function deckSearchSongs(query, append = false) {
    if (!append) {
      if (deckSearchDebounce) clearTimeout(deckSearchDebounce);
      deckSearchDebounce = setTimeout(() => {
        executeDeckSearch(query, false);
      }, 150);
    } else {
      executeDeckSearch(query, true);
    }
  }

  function executeDeckSearch(query, append) {
    const resultsContainer = document.getElementById('tv-deck-search-results');
    if (!resultsContainer) return;

    if (!append) {
      currentDeckSearchOffset = 0;
      currentDeckSearchQuery = (query !== undefined ? query : '').trim();
      hasMoreDeckResults = true;
      resultsContainer.innerHTML = '<div style="padding:14px;text-align:center;color:var(--text-muted);font-size:0.75rem;">Loading songs...</div>';
    }

    if (isDeckSearching) return;
    if (append && !hasMoreDeckResults) return;

    isDeckSearching = true;

    let loadingIndicator = null;
    if (append) {
      loadingIndicator = document.createElement('div');
      loadingIndicator.id = 'tv-deck-more-loading';
      loadingIndicator.style.cssText = 'padding:6px;text-align:center;color:var(--accent-cyan);font-size:0.65rem;';
      loadingIndicator.textContent = 'Loading more songs...';
      resultsContainer.appendChild(loadingIndicator);
    }

    fetch(`/api/search?q=${encodeURIComponent(currentDeckSearchQuery)}&offset=${currentDeckSearchOffset}&limit=${DECK_PAGE_SIZE}`)
      .then(res => res.json())
      .then(data => {
        if (loadingIndicator && loadingIndicator.parentNode) {
          loadingIndicator.parentNode.removeChild(loadingIndicator);
        }

        if (!append) resultsContainer.innerHTML = '';

        if (!data.results || data.results.length === 0) {
          if (!append) {
            resultsContainer.innerHTML = '<div style="padding:14px;text-align:center;color:var(--text-muted);font-size:0.75rem;">No songs found</div>';
          }
          hasMoreDeckResults = false;
          isDeckSearching = false;
          return;
        }

        const itemsFragment = document.createDocumentFragment();
        data.results.forEach(s => {
          const div = document.createElement('div');
          div.className = 'tv-deck-item';
          const codeStr = String(s.num).padStart(5, '0');
          div.innerHTML = `
            <div>
              <div class="tv-deck-item-code">#${codeStr}</div>
              <div class="tv-deck-item-title">${escapeHtml(s.title || '')}</div>
              <div class="tv-deck-item-artist">${escapeHtml(s.artist || '')}</div>
            </div>
            <div class="tv-deck-item-actions">
              <button class="tv-deck-mini-btn" onclick="window.SinghubHost.deckSelectPlay(${s.num})" title="Play Song">PLAY</button>
              <button class="tv-deck-mini-btn res" onclick="window.SinghubHost.deckSelectReserve(${s.num})" title="Reserve Song">+RES</button>
            </div>
          `;
          itemsFragment.appendChild(div);
        });

        resultsContainer.appendChild(itemsFragment);
        currentDeckSearchOffset += data.results.length;

        if (data.results.length < DECK_PAGE_SIZE) {
          hasMoreDeckResults = false;
        }
        isDeckSearching = false;
      })
      .catch(e => {
        if (loadingIndicator && loadingIndicator.parentNode) {
          loadingIndicator.parentNode.removeChild(loadingIndicator);
        }
        isDeckSearching = false;
        if (!append) {
          resultsContainer.innerHTML = '<div style="padding:14px;text-align:center;color:#ff2a70;font-size:0.75rem;">Error loading songs</div>';
        }
      });
  }

  function deckSelectPlay(num) {
    dialCancel();
    loadSong(num);
  }

  function deckSelectReserve(num) {
    dialCancel();
    fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'reserve', num: num })
    })
    .then(() => {
      syncQueueWithServer();
    })
    .catch(() => {});
  }

  function deckClearQueue() {
    fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'clear_queue' })
    })
    .then(() => {
      songQueue = [];
      lastQueueJson = '[]';
      updatePlayingHeader();
      renderTvDeckQueue();
    })
    .catch(() => {});
  }

  function renderTvDeckQueue() {
    const list = document.getElementById('tv-deck-queue-list');
    const countBadge = document.getElementById('tv-deck-q-count');
    if (countBadge) countBadge.textContent = songQueue.length;
    if (!list) return;

    if (songQueue.length === 0) {
      list.innerHTML = '<div style="padding:14px;text-align:center;color:var(--text-muted);font-size:0.75rem;">No songs in queue</div>';
      return;
    }

    list.innerHTML = songQueue.map((s, idx) => `
      <div class="tv-deck-item">
        <div>
          <div class="tv-deck-item-code">#${String(s.num).padStart(5, '0')}</div>
          <div class="tv-deck-item-title">${escapeHtml(s.title || '')}</div>
          <div class="tv-deck-item-artist">${escapeHtml(s.artist || '')}</div>
        </div>
        <div>
          <button class="tv-deck-mini-btn" style="background:#ff2a70;color:#fff;display:inline-flex;align-items:center;justify-content:center;" onclick="window.SinghubHost.deckRemoveQueue(${idx})" title="Remove from queue"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button>
        </div>
      </div>
    `).join('');
  }

  function deckRemoveQueue(idx) {
    fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'remove_queue', index: idx })
    })
    .then(() => {
      if (idx >= 0 && idx < songQueue.length) songQueue.splice(idx, 1);
      lastQueueJson = JSON.stringify(songQueue);
      updatePlayingHeader();
      renderTvDeckQueue();
    })
    .catch(() => {});
  }

  // Global interface for Android WebView bridge & external callers
  window.SinghubHost = {
    handleRemoteCommand: (cmd) => executeCommand(cmd),
    onRemotesCountChanged: (count) => {
      window._remotesCount = count;
      broadcastState();
    },
    executeCommand: executeCommand,
    onDigitPress: onDigitPress,
    dialCommit: () => dialCommit(true),  // Bridge always commits explicitly (OK press)
    dialCancel: dialCancel,
    togglePlayPause: togglePlayPause,
    nextSong: nextSong,
    replaySong: replaySong,
    stopSong: stopSong,
    shiftKey: shiftKey,
    shiftTempo: shiftTempo,
    switchNextBgv: switchNextBgv,
    openQrModal: openQrModal,
    openSettingsModal: openSettingsModal,
    closeAllModals: closeAllModals,
    cycleSetting: cycleSetting,
    applySettings: applySettings,
    rescanContent: rescanContent,
    toggleMelody: toggleMelody,
    toggleMpx: toggleMpx,
    toggleProj: toggleProj,
    cycleMode: cycleMode,
    cycleActiveBgv: cycleActiveBgv,
    cycleActivePhoto: cycleActivePhoto,
    cycleSoundfont: cycleSoundfont,
    openMediaManager: openMediaManager,
    closeMediaManager: closeMediaManager,
    switchMediaTab: switchMediaTab,
    loadMediaManagerList: loadMediaManagerList,
    selectMediaFromTv: selectMediaFromTv,
    deleteMediaFromTv: deleteMediaFromTv,
    pickAndAddMediaFromTv: pickAndAddMediaFromTv,
    updateActiveMediaLabels: updateActiveMediaLabels,
    onMediaUpdated: (type, name) => {
      updateActiveMediaLabels();
      if (type === 'bgv' && name) {
        const bgp = document.getElementById('bg-photo');
        if (bgp) bgp.style.display = 'none';
        playBgVideoUrl('/video?name=' + encodeURIComponent(name) + '&t=' + Date.now());
      } else if (type === 'photo' && name) {
        const bgp = document.getElementById('bg-photo');
        const bgv = document.getElementById('bg-video');
        if (bgv) { bgv.pause(); bgv.style.display = 'none'; }
        if (bgp) {
          bgp.style.display = 'block';
          bgp.src = '/api/media/photo?name=' + encodeURIComponent(name) + '&t=' + Date.now();
        }
      } else if (type === 'soundfont' && name) {
        const isBundled = (!name || name === 'bundled' || name === 'default' || name === 'undefined' || name.includes('Built-in') || name.includes('SAM5504B'));
        const safeName = isBundled ? 'bundled' : name;
        if (safeName !== currentSettings.soundfont) {
          currentSettings.soundfont = safeName;
          const wm = document.getElementById('web-midi-player');
          if (wm) wm.setAttribute('sound-font', safeName === 'bundled' ? '/sound/web_gm.sf2' : ('/api/soundfont/active?t=' + Date.now()));
        }
      }
      const modal = document.getElementById('modal-tv-media');
      if (modal && modal.style.display === 'flex') {
        loadMediaManagerList(currentMediaTab);
      }
    },
    onWebPatchApplied: (ver) => {
      console.log('[SINGHUB-PATCH] Hot patch v' + ver + ' applied.');
      if (isPlaying) {
        window._pendingPatchReload = true;
      } else {
        window.location.reload();
      }
    },
    onSongCompleted: onSongCompleted,
    toggleTvDeck: toggleTvDeck,
    switchTvDeckTab: switchTvDeckTab,
    deckPressClear: deckPressClear,
    deckPressBackspace: deckPressBackspace,
    deckActionPlay: deckActionPlay,
    deckActionReserve: deckActionReserve,
    deckSearchSongs: deckSearchSongs,
    deckSelectPlay: deckSelectPlay,
    deckSelectReserve: deckSelectReserve,
    deckClearQueue: deckClearQueue,
    deckRemoveQueue: deckRemoveQueue,
    onTvNav: (dir) => TvNavigator.navigate(dir),
    onTvColor: (color) => handleTvColor(color),
    onBackPressed: () => {
      if (isDownloadActive || (typeof isAppUpdating !== 'undefined' && isAppUpdating)) {
        showToast('⚠️ DONT CLOSE: Download in progress');
        return;
      }
      if (TvNavigator.getContext() === 'update') {
        closeUpdateModal();
        return;
      }
      if (TvNavigator.getContext() === 'settings' || TvNavigator.getContext() === 'qr' || TvNavigator.getContext() === 'score' || TvNavigator.getContext() === 'media') {
        closeAllModals();
      } else if (isTvDeckOpen) {
        toggleTvDeck(false);
      } else if (dialBuffer) {
        dialCancel();
      } else {
        showToast('Press Home to exit or Remote to control');
      }
    },
    // In-App Auto-Updater Interface
    checkForUpdates: checkForUpdates,
    openUpdateModal: openUpdateModal,
    closeUpdateModal: closeUpdateModal,
    startUpdateDownload: startUpdateDownload,
    cancelUpdateDownload: cancelUpdateDownload,
    installDownloadedApk: installDownloadedApk,
    onUpdateCheckResult: onUpdateCheckResult,
    onUpdateProgress: onUpdateProgress,
    onUpdateComplete: onUpdateComplete,
    onUpdateFailed: onUpdateFailed,
    onEngineReady: (count) => {
      console.log('Engine ready callback with count:', count);
      checkResourceStatus(false);
    },
    onStorageRescanned: () => {
      showToast('Storage Rescanned: Ready!');
      checkResourceStatus(false);
    },
    confirmFirstTimeDownload: confirmFirstTimeDownload,
    openDownloadModal: openDownloadModal,
    startResourceDownload: startResourceDownload,
    cancelResourceDownload: cancelResourceDownload,
    onDownloadProgress: (fileName, percent, downloadedBytes, totalBytes) => {
      const bar = document.getElementById('dl-bar-main');
      const fill = document.getElementById('dl-fill-main');
      const statusText = document.getElementById('dl-status-main');
      const badge = document.getElementById('dl-badge-main');

      if (bar) bar.style.display = 'block';
      if (fill) fill.style.width = percent + '%';
      if (badge) {
        badge.textContent = percent + '%';
        badge.style.background = 'rgba(0,229,255,0.2)';
        badge.style.color = '#00e5ff';
      }
      if (statusText) {
        const mb = (downloadedBytes / (1024 * 1024)).toFixed(1);
        const totalMb = totalBytes > 0 ? (totalBytes / (1024 * 1024)).toFixed(1) : '638.2';
        statusText.textContent = `Downloading Resources: ${mb}MB / ${totalMb}MB (${percent}%)`;
        statusText.style.color = '#00e5ff';
      }
    },
    onDownloadCompleted: (fileName) => {
      const fill = document.getElementById('dl-fill-main');
      const statusText = document.getElementById('dl-status-main');
      const badge = document.getElementById('dl-badge-main');

      if (fill) fill.style.width = '100%';
      if (badge) {
        badge.textContent = 'DONE ✓';
        badge.style.background = 'rgba(0,245,155,0.2)';
        badge.style.color = '#00f59b';
      }
      if (statusText) {
        statusText.textContent = 'Resources installed successfully';
        statusText.style.color = '#00f59b';
      }
    },
    onDownloadFailed: (fileName, error) => {
      const statusText = document.getElementById('dl-status-main');
      const badge = document.getElementById('dl-badge-main');
      if (badge) {
        badge.textContent = 'FAILED ✕';
        badge.style.background = 'rgba(255,59,48,0.2)';
        badge.style.color = '#ff6b6b';
      }
      if (statusText) {
        statusText.textContent = 'Error downloading resources: ' + error;
        statusText.style.color = '#ff6b6b';
      }

      const errB = document.getElementById('dl-error-banner');
      if (errB) {
        errB.style.display = 'block';
        errB.textContent = '✕ Download failed: Check internet connection or server reachability and retry.';
      }
      const startBtn = document.getElementById('dl-btn-start');
      if (startBtn) {
        startBtn.style.display = 'block';
        startBtn.textContent = '↻ Retry Download';
      }
    },
    onDownloadAllDone: (allSuccess) => {
      const startBtn = document.getElementById('dl-btn-start');
      isDownloadActive = false;

      if (allSuccess) {
        const fill = document.getElementById('dl-fill-main');
        const badge = document.getElementById('dl-badge-main');
        const statusText = document.getElementById('dl-status-main');
        if (fill) fill.style.width = '100%';
        if (badge) {
          badge.textContent = 'READY ✓';
          badge.style.background = 'rgba(0,245,155,0.2)';
          badge.style.color = '#00f59b';
        }
        if (statusText) {
          statusText.textContent = 'Resources installed and ready to sing!';
          statusText.style.color = '#00f59b';
        }
        if (startBtn) {
          startBtn.style.display = 'block';
          startBtn.textContent = '✓ All Ready';
        }
        // Don't call checkResourceStatus immediately — engine rescan runs async.
        // onStorageRescanned will fire once engine finishes and updates the UI.
        setTimeout(() => checkResourceStatus(false), 3000);

        // 5-second auto close timer
        let leftSec = 5;
        const countEl = document.getElementById('dl-countdown-sec');
        if (countEl) countEl.textContent = leftSec;
        const cDown = document.getElementById('dl-complete-countdown');
        if (cDown) cDown.style.display = 'block';
        const errB = document.getElementById('dl-error-banner');
        if (errB) errB.style.display = 'none';

        if (downloadCountdownTimer) clearInterval(downloadCountdownTimer);
        downloadCountdownTimer = setInterval(() => {
          leftSec--;
          if (countEl) countEl.textContent = leftSec;
          if (leftSec <= 0) {
            clearInterval(downloadCountdownTimer);
            downloadCountdownTimer = null;
            closeAllModals();
            showToast('All resources installed successfully! Ready to sing!');
          }
        }, 1000);
      } else {
        const errB = document.getElementById('dl-error-banner');
        if (errB) {
          errB.style.display = 'block';
          errB.textContent = '✕ Download failed: No internet or server error. Please check your network and retry.';
        }
        if (startBtn) {
          startBtn.style.display = 'block';
          startBtn.textContent = '↻ Retry Download';
        }
      }
    }
  };

  // --- 12. Initialization on Load ---
  window.addEventListener('DOMContentLoaded', () => {
    restoreTvDeckWrapper();
    requestAnimationFrame(syncKaraokeLoop);
    // When running inside Android TV host app, Java bridge provides instant direct push.
    // Only poll /api/command/poll if running in standalone web browser.
    if (!window.SinghubNative) {
      pollCommands();
    }
    syncQueueWithServer();

    // Fetch initial settings from server
    fetch('/api/settings')
      .then(res => res.json())
      .then(s => {
        if (s) applySettings(s);
      })
      .catch(() => {});

    // Fetch and continuously update TV Server IP in top bar & settings
    function updateTvServerBadge() {
      const badge = document.getElementById('remote-ip-badge');
      const sSub = document.getElementById('tv-server-ip-sub');

      let nativeIp = null;
      let nativePort = 8000;
      if (window.SinghubNative && typeof window.SinghubNative.getDeviceIp === 'function') {
        try {
          nativeIp = window.SinghubNative.getDeviceIp();
          if (window.SinghubNative.getServerPort) nativePort = window.SinghubNative.getServerPort();
        } catch (e) {}
      }

      const applyIp = (ip, port) => {
        if (!ip || ip === '127.0.0.1' || ip === '0.0.0.0') return;
        const addr = `${ip}:${port || 8000}`;
        if (badge) badge.textContent = addr;
        if (sSub) sSub.textContent = `Active: http://${addr}`;
        const qrText = document.getElementById('qr-url-text');
        if (qrText && (!qrText.textContent || qrText.textContent.includes('127.0.0.1'))) {
          generateQr();
        }
      };

      if (nativeIp && nativeIp !== '127.0.0.1') {
        applyIp(nativeIp, nativePort);
      }

      fetch('/api/stats', { headers: AUTH_HEADERS })
        .then(res => res.json())
        .then(data => {
          if (data && data.ip && data.ip !== '127.0.0.1') {
            applyIp(data.ip, data.port || nativePort);
          }
        })
        .catch(() => {})
        .finally(() => {
          setTimeout(updateTvServerBadge, 2500);
        });
    }

    updateTvServerBadge();

    // Infinite scroll listener for TV stage on-screen keypad deck songs
    const deckResults = document.getElementById('tv-deck-search-results');
    if (deckResults) {
      deckResults.addEventListener('scroll', () => {
        if (deckResults.scrollTop + deckResults.clientHeight >= deckResults.scrollHeight - 35) {
          if (hasMoreDeckResults && !isDeckSearching) {
            deckSearchSongs(currentDeckSearchQuery, true);
          }
        }
      });
    }

    // Setup Background Video (BGV) to continuously play and auto-recover
    const bgvVideo = document.getElementById('bg-video');
    if (bgvVideo) {
      bgvVideo.muted = true;
      bgvVideo.defaultMuted = true;
      bgvVideo.volume = 0;
      bgvVideo.loop = true;

      // When current video finishes, smoothly rotate to next BGV
      bgvVideo.addEventListener('ended', () => {
        switchNextBgv();
      });

      // Handle video error with graceful retry
      let bgvRetryTimer = null;
      bgvVideo.addEventListener('error', (e) => {
        console.warn('BGV video load error, retrying in 2.5s...', e);
        if (bgvRetryTimer) clearTimeout(bgvRetryTimer);
        bgvRetryTimer = setTimeout(() => {
          switchNextBgv();
        }, 2500);
      });

      // Continuous Watchdog: Ensure video stays playing whenever TV stage is visible
      setInterval(() => {
        if (bgvVideo && bgvVideo.paused && (!currentSettings.bgvMode || currentSettings.bgvMode === 'video')) {
          bgvVideo.muted = true;
          bgvVideo.play().catch(() => {});
        }
      }, 4000);

      // Autoplay unlocker: Any user touch, click, or remote key press resumes video if paused
      const resumeBgv = () => {
        if (bgvVideo && bgvVideo.paused && (!currentSettings.bgvMode || currentSettings.bgvMode === 'video')) {
          bgvVideo.muted = true;
          bgvVideo.play().catch(() => {});
        }
      };
      document.addEventListener('click', resumeBgv, { passive: true });
      document.addEventListener('keydown', resumeBgv, { passive: true });

      // Start initial video with a random pick (not sequential)
      fetch('/api/bgv/random', { headers: AUTH_HEADERS })
        .then(r => r.ok ? r.json() : null)
        .then(data => {
          if (data && data.url) playBgVideoUrl(data.url);
          else playBgVideoUrl('/video?t=' + Date.now());
        })
        .catch(() => playBgVideoUrl('/video?t=' + Date.now()));
    }

    // Restore persisted settings from localStorage and server
    try {
      const savedTvSettings = localStorage.getItem('singhub_tv_settings');
      if (savedTvSettings) {
        const parsed = JSON.parse(savedTvSettings);
        if (parsed && typeof parsed === 'object') applySettings(parsed);
      }
    } catch (e) {}
    fetch('/api/settings', { headers: AUTH_HEADERS })
      .then(r => r.ok ? r.json() : null)
      .then(serverSet => {
        if (serverSet && typeof serverSet === 'object') applySettings(serverSet);
      })
      .catch(() => {});

    // Initial state: SELECT A SONG (00000)
    showIdleSelectState();
    initTvDeckResizer();
    setTimeout(() => {
      checkResourceStatus(false);
      updateActiveMediaLabels();
      checkForUpdates(false);
    }, 2000);

    // Periodic background check every 5 minutes
    setInterval(() => {
      checkForUpdates(false);
    }, 5 * 60 * 1000);
  });

})();
